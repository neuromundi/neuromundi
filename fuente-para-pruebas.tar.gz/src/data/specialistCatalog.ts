/**
 * specialistCatalog — catálogos para el registro y la indexación de especialistas.
 * Los valores (`value`) son claves canónicas que se guardan e indexan; las
 * etiquetas están en español (pueden localizarse más adelante).
 */
export interface CatItem { value: string; label: string }

/** Prefijos de título. `value` = clave estable (se guarda); `label` = respaldo es.
 *  Se localizan con `cat.<value>` (equivalentes más cercanos por idioma). */
export const TITLE_PREFIXES: CatItem[] = [
  { value: 'dr', label: 'Dr.' },
  { value: 'dra', label: 'Dra.' },
  { value: 'lic', label: 'Lic.' },
  { value: 'mtro', label: 'Mtro.' },
  { value: 'mtra', label: 'Mtra.' },
  { value: 'ing', label: 'Ing.' },
  { value: 'psic', label: 'Psic.' },
  { value: 'to', label: 'T.O.' },
  { value: 'fga', label: 'Fga.' },
  { value: 'fgo', label: 'Fgo.' },
];

export const PROFESSIONS: CatItem[] = [
  { value: 'psicologia_clinica', label: 'Psicología Clínica' },
  { value: 'psicologia_infantil', label: 'Psicología Infantil' },
  { value: 'terapia_ocupacional', label: 'Terapia Ocupacional' },
  { value: 'logopedia', label: 'Logopedia / Fonoaudiología' },
  { value: 'fisioterapia', label: 'Fisioterapia' },
  { value: 'neuropediatria', label: 'Neuropediatría' },
  { value: 'psicopedagogia', label: 'Psicopedagogía' },
  { value: 'psiquiatria', label: 'Psiquiatría' },
  { value: 'paidopsiquiatria', label: 'Paidopsiquiatría (psiquiatría infantil)' },
  { value: 'neurologia', label: 'Neurología' },
  { value: 'pediatria', label: 'Pediatría' },
  { value: 'genetica_medica', label: 'Genética Médica' },
  { value: 'neuropatologia', label: 'Neuropatología' },
  { value: 'medicina_rehabilitacion', label: 'Medicina Física y Rehabilitación' },
  { value: 'neuropsicologia', label: 'Neuropsicología' },
  { value: 'educacion_especial', label: 'Educación Especial' },
  { value: 'nutricion', label: 'Nutrición' },
  { value: 'musicoterapia', label: 'Musicoterapia' },
  // ── Ampliación (taxonomía Neuromundi) ──────────────────────────────────────
  { value: 'psicomotricidad', label: 'Psicomotricidad' },
  { value: 'lactancia', label: 'Consultoría de Lactancia (IBCLC)' },
  { value: 'consultoria_sueno', label: 'Consultoría de Sueño Infantil' },
  { value: 'asesoria_porteo', label: 'Asesoría de Porteo' },
  { value: 'terapia_miofuncional', label: 'Terapia Miofuncional Orofacial' },
  { value: 'optometria_comportamental', label: 'Optometría Comportamental / Terapia Visual' },
  { value: 'neurofeedback', label: 'Neurofeedback / Biofeedback' },
  { value: 'terapia_neurosensorial', label: 'Terapia Neurosensorial (Tomatis, Bérard, SSP)' },
  { value: 'arteterapia', label: 'Arteterapia' },
  { value: 'coaching_ejecutivo', label: 'Coaching de Funciones Ejecutivas' },
  { value: 'acompanante_terapeutico', label: 'Acompañante Terapéutico (Maestro/a Sombra)' },
  { value: 'transicion_vida_independiente', label: 'Especialista en Transición / Vida Independiente' },
  { value: 'terapia_familiar', label: 'Terapia Familiar y Sistémica' },
  { value: 'trabajo_social', label: 'Trabajo Social' },
  { value: 'accesibilidad_cognitiva', label: 'Consultoría en Accesibilidad Cognitiva (B2B)' },
  { value: 'odontologia_inclusiva', label: 'Odontología para pacientes neurodivergentes' },
  // ── Afecciones neurológicas ─────────────────────────────────────────────────
  { value: 'neurocirugia', label: 'Neurocirugía' },
  { value: 'epileptologia', label: 'Epileptología' },
  { value: 'neurogeriatria', label: 'Neurogeriatría' },
  { value: 'neurorrehabilitacion', label: 'Neurorrehabilitación' },
  { value: 'fisioterapia_neurologica', label: 'Fisioterapia Neurológica' },
  { value: 'enfermeria_neurologica', label: 'Enfermería Neurológica y Cuidados' },
  // ── Dominio: Terapia y Asistencia con Animales (Neuro-Friendly) ─────────────
  { value: 'taa_equinoterapia', label: 'Equinoterapia / Hipoterapia' },
  { value: 'taa_perros', label: 'Terapia Asistida con Perros' },
  { value: 'taa_granja', label: 'Granja Terapéutica' },
  { value: 'entrenador_psaa', label: 'Entrenador de Perros de Asistencia (PSAA)' },
  { value: 'certificador_aae', label: 'Evaluador / Certificador de Animales de Apoyo Emocional' },
  { value: 'adiestramiento_positivo', label: 'Adiestramiento Canino Positivo' },
  { value: 'veterinaria_neurofriendly', label: 'Veterinaria de Baja Estimulación (Neuro-Friendly)' },
  { value: 'cuidado_mascotas_nf', label: 'Cuidado y Paseo de Mascotas (Neuro-Friendly)' },
  // ── Dominio: Arte, Música y Expresión (neuroafirmativo) ─────────────────────
  { value: 'danzaterapia', label: 'Danzaterapia / Terapia de Movimiento' },
  { value: 'profesor_musica_adaptada', label: 'Profesor de Instrumento y Canto Adaptado' },
  { value: 'instructor_artes_visuales', label: 'Instructor de Artes Visuales y Digitales' },
  { value: 'coach_teatro', label: 'Coach de Teatro y Expresión Corporal' },
  { value: 'organizador_eventos_sensory', label: 'Organizador de Eventos Sensory-Friendly' },
  { value: 'director_ensamble_nd', label: 'Director de Coros / Ensambles Neurodivergentes' },
  { value: 'gestor_colectivo_artistico', label: 'Gestor de Colectivos Artísticos' },
  { value: 'mentor_artistas', label: 'Mentor de Artistas y Creativos' },
  { value: 'agente_talento_inclusivo', label: 'Agente de Talento Inclusivo' },
  { value: 'otro', label: 'Otro' },
];

/**
 * Profesiones MÉDICAS, para efectos de cuota de afiliación.
 *
 * Criterio (el mismo que usan los estándares reconocidos):
 *  · ISCO-08 (OIT/OMS) reserva "médicos" al grupo 221 —2211 generalistas y
 *    2212 especialistas—; el resto del personal de salud (psicología 2634,
 *    fisioterapia 2264, logopedia 2266, nutrición 2265, terapia ocupacional)
 *    son "profesionales de la salud", pero NO médicos.
 *  · En México, la Ley General de Salud (art. 79) enumera muchas profesiones
 *    sanitarias que exigen título, pero distingue la medicina de las demás.
 *
 * En la práctica la línea divisoria es el título de médico cirujano y, con él,
 * la facultad de diagnosticar enfermedades y prescribir medicamentos.
 *
 * Nota: psicología, neuropsicología, logopedia, fisioterapia, terapia
 * ocupacional, psicopedagogía, educación especial, nutrición y musicoterapia
 * son profesiones de la salud o de la educación, pero no médicas.
 */
export const MEDICAL_PROFESSIONS: ReadonlySet<string> = new Set([
  'psiquiatria',
  'paidopsiquiatria',
  'neuropediatria',
  'neurologia',
  'pediatria',
  'genetica_medica',
  'neuropatologia',
  'medicina_rehabilitacion',
  'neurocirugia',
  'epileptologia',
  'neurogeriatria',
]);

/**
 * ¿La profesión es médica? 'otro' y los valores desconocidos devuelven `null`:
 * no se puede afirmar, así que los revisa el administrador al verificar la
 * cédula profesional (que es la fuente autorizada).
 */
export function isMedicalProfession(value: string | null | undefined): boolean | null {
  if (!value) return null;
  if (value === 'otro') return null;
  if (MEDICAL_PROFESSIONS.has(value)) return true;
  return PROFESSIONS.some((p) => p.value === value) ? false : null;
}

export const SPECIALTIES: CatItem[] = [
  { value: 'tea', label: 'Trastorno del Espectro Autista (TEA)' },
  { value: 'tdah', label: 'TDAH' },
  { value: 'lenguaje', label: 'Trastornos del Lenguaje y Habla' },
  { value: 'aprendizaje', label: 'Dificultades de Aprendizaje' },
  { value: 'sensorial', label: 'Procesamiento Sensorial' },
  { value: 'discapacidad_intelectual', label: 'Discapacidad Intelectual' },
  { value: 'estimulacion_temprana', label: 'Estimulación Temprana' },
  { value: 'conducta', label: 'Manejo Conductual' },
  { value: 'habilidades_sociales', label: 'Habilidades Sociales' },
  { value: 'funciones_ejecutivas', label: 'Funciones Ejecutivas' },
  { value: 'sindrome_down', label: 'Síndrome de Down' },
  { value: 'paralisis_cerebral', label: 'Parálisis Cerebral' },
  // ── Ampliación (taxonomía Neuromundi) ──────────────────────────────────────
  { value: 'arfid_selectividad', label: 'Selectividad alimentaria / ARFID' },
  { value: 'mutismo_selectivo', label: 'Mutismo Selectivo' },
  { value: 'dislexia', label: 'Dislexia' },
  { value: 'discalculia', label: 'Discalculia' },
  { value: 'disgrafia', label: 'Disgrafía' },
  { value: 'dispraxia', label: 'Dispraxia / Trastorno del Desarrollo de la Coordinación' },
  { value: 'altas_capacidades', label: 'Altas Capacidades / Doble Excepcionalidad (2e)' },
  { value: 'tourette', label: 'Síndrome de Tourette / Tics' },
  { value: 'tpac', label: 'Trastorno del Procesamiento Auditivo Central (TPAC)' },
  { value: 'sordoceguera', label: 'Discapacidad múltiple / Sordoceguera' },
  { value: 'trastornos_sueno', label: 'Trastornos del Sueño' },
  { value: 'trauma_tept', label: 'Trauma / TEPT' },
  { value: 'otro', label: 'Otro' },
];

export const MODALITIES: CatItem[] = [
  { value: 'consultorio', label: 'Consultorio privado' },
  { value: 'online', label: 'En línea' },
  { value: 'domicilio', label: 'A domicilio' },
  { value: 'escuelas', label: 'Atención en escuelas' },
];

export const AGE_RANGES: CatItem[] = [
  { value: '0_3', label: '0–3 años' },
  { value: '3_6', label: '3–6 años' },
  { value: '6_12', label: '6–12 años' },
  { value: 'adolescentes', label: 'Adolescentes' },
  { value: 'adultos', label: 'Adultos' },
];

/**
 * Accesibilidad física y sensorial del lugar de atención. Se guarda en
 * profiles.provider_details.accessibility (string[]) y se muestra como chips en
 * el perfil. Localización por i18n con la clave cat.<value> (respaldo: label).
 */
export const ACCESSIBILITY_FEATURES: CatItem[] = [
  { value: 'rampa_acceso', label: 'Rampa de acceso' },
  { value: 'bano_accesible', label: 'Baño accesible' },
  { value: 'estacionamiento_accesible', label: 'Estacionamiento accesible' },
  { value: 'elevador', label: 'Elevador / ascensor' },
  { value: 'espacio_calma', label: 'Espacio de calma sensorial' },
  { value: 'bajo_estimulo', label: 'Ambiente de bajo estímulo sensorial' },
  { value: 'comunicacion_alternativa', label: 'Apoyos de comunicación (CAA / pictogramas)' },
  { value: 'perro_asistencia', label: 'Acceso a perro de asistencia' },
];

export const INTERVENTION_AREAS: CatItem[] = [
  { value: 'integracion_sensorial', label: 'Integración Sensorial' },
  { value: 'estimulacion_temprana', label: 'Estimulación Temprana' },
  { value: 'modificacion_conducta', label: 'Modificación de Conducta' },
  { value: 'habilidades_sociales', label: 'Desarrollo de Habilidades Sociales' },
  { value: 'lenguaje_habla', label: 'Lenguaje y Habla' },
  { value: 'motricidad', label: 'Motricidad y Psicomotricidad' },
  { value: 'funciones_ejecutivas', label: 'Funciones Ejecutivas' },
  { value: 'autonomia', label: 'Autonomía y AVD' },
  // ── Ampliación (taxonomía Neuromundi) ──────────────────────────────────────
  { value: 'saac', label: 'Comunicación Aumentativa (SAAC)' },
  { value: 'adaptacion_curricular', label: 'Adaptación Curricular / Ajustes Razonables' },
  { value: 'vida_independiente', label: 'Vida Independiente / Transición' },
  { value: 'psicoeducacion_familia', label: 'Psicoeducación / Escuela para Familias' },
  { value: 'grupos_pares', label: 'Grupos de Apoyo entre Pares' },
  { value: 'regulacion_emocional', label: 'Regulación Emocional' },
  { value: 'terapia_miofuncional', label: 'Terapia Miofuncional' },
  { value: 'estimulacion_auditiva', label: 'Estimulación Auditiva (Tomatis / Bérard)' },
  { value: 'regulacion_polivagal', label: 'Regulación Polivagal (SSP)' },
  { value: 'procesamiento_visual', label: 'Procesamiento Visual / Terapia Visual' },
  { value: 'lactancia_motricidad_oral', label: 'Lactancia y Motricidad Oral' },
  // ── Arte, Música y Expresión ────────────────────────────────────────────────
  { value: 'expresion_creativa', label: 'Expresión Artística y Creativa' },
  { value: 'movimiento_danza', label: 'Movimiento y Danza Terapéutica' },
  { value: 'teatro_rol', label: 'Teatro y Juego de Roles Sociales' },
  { value: 'ocio_sensorial', label: 'Ocio y Eventos Sensory-Friendly' },
  // ── Afecciones neurológicas ─────────────────────────────────────────────────
  { value: 'neurorrehabilitacion_motora', label: 'Neurorrehabilitación motora' },
  { value: 'rehabilitacion_cognitiva', label: 'Rehabilitación cognitiva' },
  { value: 'manejo_epilepsia', label: 'Manejo de epilepsia y crisis' },
  { value: 'espasticidad_movilidad', label: 'Espasticidad y movilidad' },
  { value: 'deglucion_disfagia', label: 'Deglución y disfagia' },
  { value: 'dolor_neurologico', label: 'Manejo del dolor neurológico' },
  { value: 'cuidados_paliativos_neuro', label: 'Cuidados paliativos neurológicos' },
  // ── Diagnóstico, educación y apoyo (ampliación 2026) ─────────────────────────
  { value: 'evaluacion_diagnostica', label: 'Evaluaciones diagnósticas (ADOS-2, ADI-R, CARS)' },
  { value: 'analisis_conductual_aba', label: 'Análisis Conductual Aplicado (ABA)' },
  { value: 'psicoterapia_cc_act', label: 'Psicoterapia (Cognitivo-Conductual, ACT)' },
  { value: 'educacion_inclusiva', label: 'Escuelas inclusivas / servicios educativos especializados' },
  { value: 'capacitacion_docente', label: 'Asesoría y capacitación a docentes e instituciones' },
  { value: 'orientacion_legal_ddhh', label: 'Orientación legal y de derechos humanos' },
  { value: 'hidroterapia', label: 'Hidroterapia / Terapia acuática' },
  { value: 'inclusion_laboral', label: 'Inclusión laboral y empleo con apoyo' },
  { value: 'deporte_adaptado', label: 'Deporte adaptado e inclusivo' },
  { value: 'otro', label: 'Otro' },
];

export const CERTIFICATIONS: string[] = [
  'ADOS-2', 'ADI-R', 'CARS', 'DIR/Floortime', 'PECS', 'Método Denver (ESDM)', 'Integración Sensorial de Ayres', 'ABA', 'TEACCH', 'Hanen',
  // ── Ampliación (taxonomía Neuromundi) ──
  'Modelo Neuroafirmante', 'TCC adaptada', 'ACT', 'SCERTS', 'PROMPT', 'Terapia Miofuncional',
  'Método Tomatis', 'Método Bérard (AIT)', 'Safe & Sound Protocol (SSP)', 'Interactive Metronome',
  'HeartMath', 'WISC-V', 'IBCLC',
];
