/**
 * useDirectory — catálogo público de proveedores.
 *
 * Combina perfiles publicados (legibles por anon gracias a RLS), su EVS desde la
 * vista pública y sus categorías, mediante consultas por lote (tipado predecible).
 * Aplica los filtros en cliente: texto (con debounce desde la UI), categoría,
 * ciudad y radio en km respecto a una ubicación.
 */
import { useCallback, useEffect, useMemo, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { haversineKm, toMessage, providerOtherText } from '@/lib/utils';
import { computeBadge, type BadgeResult } from '@/lib/badge';
import { inputsFromRow } from '@/hooks/useProviderBadge';
import { SPECIALTIES, INTERVENTION_AREAS, PROFESSIONS } from '@/data/specialistCatalog';
import { PRODUCT_CATEGORIES } from '@/data/providerCatalog';
import { K_OFFERINGS } from '@/data/kCatalog';
import { NEURO_CONDITIONS } from '@/data/neuroConditionsCatalog';
import type {
  Category,
  ProviderRating,
  ProviderWithRating,
  PerfilPublico,
} from '@/types/app';

const K_ALL = Object.values(K_OFFERINGS).flat();
const LABEL = new Map<string, string>([
  ...NEURO_CONDITIONS.map((x) => [x.value, x.label] as const),
  ...SPECIALTIES.map((x) => [x.value, x.label] as const),
  ...INTERVENTION_AREAS.map((x) => [x.value, x.label] as const),
  ...PROFESSIONS.map((x) => [x.value, x.label] as const),
  ...PRODUCT_CATEGORIES.map((x) => [x.value, x.label] as const),
  ...K_ALL.map((x) => [x.value, x.label] as const),
]);
const labelsOf = (arr?: string[] | null) => (arr ?? []).map((v) => LABEL.get(v) ?? v).join(' ');

export interface DirectoryFilters {
  /** Texto libre (nombre, profesión, especialidad, producto…). */
  query?: string;
  categoryId?: number;
  /** Especialidad o área de intervención (clave canónica). */
  specialty?: string;
  /** Categoría de producto (proveedores). */
  productCategory?: string;
  /** Rango de edad atendido. */
  ageRange?: string;
  /** Acceso rápido por dominio: pasa si la profesión, alguna especialidad, área
   *  o categoría de producto del proveedor está en esta lista. */
  anyOf?: string[];
  /** Acceso rápido por TIPO de proveedor (wellness, tourism, legal, ngo,
   *  caregiver, company…): pasa si `provider_type` está en esta lista. */
  providerTypes?: string[];
  /** Modalidad de atención. */
  modality?: string;
  /** Solo proveedores con el Sello Neuromundi Neuroafirmativo. */
  neuroaffirming?: boolean;
  /** Sección de la plataforma: neurodesarrollo | neurodivergencias | afecciones. */
  section?: string;
  /** Afección neurológica (clave canónica) — solo relevante en la sección de afecciones. */
  neuroCondition?: string;
  city?: string;
  /** País (nombre) para segmentar el directorio a un solo país. */
  country?: string;
  /** Centro para el filtro por distancia. */
  center?: { lat: number; lng: number };
  /** Radio en km; solo aplica si hay `center`. */
  radiusKm?: number;
}

export interface UseDirectoryValue {
  providers: ProviderWithRating[];
  /** Subconjunto tras aplicar los filtros activos. */
  filtered: ProviderWithRating[];
  cities: string[];
  loading: boolean;
  error: string | null;
  refetch: () => Promise<void>;
}

export function useDirectory(filters: DirectoryFilters): UseDirectoryValue {
  const [providers, setProviders] = useState<ProviderWithRating[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const country = filters.country;

  const refetch = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      // 1) Catálogo público: perfiles de proveedores con cuenta MÁS fichas del
      //    directorio que todavía no tienen dueño (vista directorio_publico).
      //    Segmentado por país en el servidor: no traemos otros países.
      let query = supabase
        .from('directorio_publico_seguro')
        .select('*')
        .eq('role', 'provider')
        .eq('is_published', true);
      if (country) query = query.eq('country', country);
      const { data: profiles, error: pErr } = await query;
      if (pErr) throw pErr;

      // La vista pierde los NOT NULL de la tabla, así que sus columnas llegan
      // nulables. `id`, `role` y `provider_type` sí vienen siempre: la vista
      // sólo expone perfiles publicados y fichas publicadas.
      const list = (profiles ?? []) as unknown as PerfilPublico[];
      const ids = list.map((p) => p.id);
      if (ids.length === 0) {
        setProviders([]);
        return;
      }

      // 2) EVS + 3) categorías + 4) fundadores, en paralelo.
      const [ratingsRes, pcRes, catsRes, badgeRes, founderRes, donorRes, typeBadgeRes] = await Promise.all([
        supabase.from('public_provider_ratings').select('*').in('provider_id', ids),
        supabase.from('provider_categories').select('*').in('provider_id', ids),
        supabase.from('categories').select('*'),
        supabase.from('provider_badge_inputs').select('*').in('provider_id', ids),
        supabase.rpc('founder_provider_ids'),
        supabase.rpc('donor_provider_ids'),
        supabase.rpc('type_badge_providers'),
      ]);
      const founderSet = new Set<string>(((founderRes.data as { id: string }[] | null) ?? []).map((r) => r.id));
      const donorSet = new Set<string>(((donorRes.data as { id: string }[] | null) ?? []).map((r) => r.id));
      type TypeBadgeRow = { id: string; is_inclusive_school: boolean; is_inclusive_company: boolean; is_institutional_ally: boolean };
      const typeBadgeMap = new Map<string, TypeBadgeRow>(
        ((typeBadgeRes.data as TypeBadgeRow[] | null) ?? []).map((r) => [r.id, r]),
      );

      const badgeMap = new Map<string, BadgeResult>(
        (badgeRes.data ?? []).filter((r) => r.provider_id).map((r) => [r.provider_id as string, computeBadge(inputsFromRow(r))]),
      );

      const ratingMap = new Map<string, ProviderRating>(
        (ratingsRes.data ?? [])
          .filter((r): r is ProviderRating & { provider_id: string } => !!r.provider_id)
          .map((r) => [r.provider_id, r]),
      );
      const catMap = new Map<number, Category>((catsRes.data ?? []).map((c) => [c.id, c]));
      const byProvider = new Map<string, Category[]>();
      for (const pc of pcRes.data ?? []) {
        const cat = catMap.get(pc.category_id);
        if (!cat) continue;
        const arr = byProvider.get(pc.provider_id) ?? [];
        arr.push(cat);
        byProvider.set(pc.provider_id, arr);
      }

      setProviders(
        list.map((p) => ({
          ...p,
          rating: ratingMap.get(p.id) ?? null,
          categories: byProvider.get(p.id) ?? [],
          badge: badgeMap.get(p.id) ?? null,
          is_founder: founderSet.has(p.id),
          is_donor: donorSet.has(p.id),
          is_inclusive_school: typeBadgeMap.get(p.id)?.is_inclusive_school ?? false,
          is_inclusive_company: typeBadgeMap.get(p.id)?.is_inclusive_company ?? false,
          is_institutional_ally: typeBadgeMap.get(p.id)?.is_institutional_ally ?? false,
        })) as ProviderWithRating[],
      );
    } catch (e) {
      setError(toMessage(e, 'No se pudo cargar el directorio.'));
    } finally {
      setLoading(false);
    }
  }, [country]);

  useEffect(() => {
    void refetch();
  }, [refetch]);

  const cities = useMemo(
    () =>
      [...new Set(providers.map((p) => p.city).filter((c): c is string => !!c))].sort(),
    [providers],
  );

  const { query, categoryId, specialty, productCategory, ageRange, modality, neuroaffirming, section, neuroCondition, city, center, radiusKm, anyOf, providerTypes } = filters;

  const filtered = useMemo(() => {
    const q = query?.trim().toLowerCase();
    const pass = providers.filter((p) => {
      if (q) {
        const haystack = [
          p.business_name ?? '', p.full_name, p.profession ?? '', p.bio ?? '',
          labelsOf(p.specialties), labelsOf(p.intervention_areas), labelsOf(p.product_categories),
          (p.products_offered ?? []).join(' '),
          // La especialización curada de las fichas llega aquí (la vista la mapea
          // desde `directorio.especializacion`). Sin esta línea, el texto que
          // describe a 669 fichas no era buscable y solo se encontraban por nombre.
          p.services_offered ?? '',
          labelsOf(p.neuro_conditions),
          providerOtherText(p.provider_details as Record<string, unknown> | null),
        ].join(' ').toLowerCase();
        if (!haystack.includes(q)) return false;
      }
      if (categoryId && !p.categories.some((c) => c.id === categoryId)) return false;
      if (specialty) {
        const inSpec = (p.specialties ?? []).includes(specialty);
        const inArea = (p.intervention_areas ?? []).includes(specialty);
        if (!inSpec && !inArea) return false;
      }
      if (productCategory && !(p.product_categories ?? []).includes(productCategory)) return false;
      if (anyOf && anyOf.length > 0) {
        const pool = [
          p.profession ?? '',
          ...(p.specialties ?? []),
          ...(p.intervention_areas ?? []),
          ...(p.product_categories ?? []),
        ];
        if (!anyOf.some((v) => pool.includes(v))) return false;
      }
      if (providerTypes && providerTypes.length > 0) {
        // Una organización puede pertenecer a VARIAS categorías (migración
        // 0097): `provider_types` trae la lista completa y `provider_type` la
        // principal. El respaldo importa: los perfiles con cuenta y las fichas
        // anteriores al backfill solo tienen la principal, y sin él dejarían
        // de salir en el directorio.
        const tipos = ((p as { provider_types?: string[] | null }).provider_types?.length
          ? (p as { provider_types?: string[] | null }).provider_types!
          : [p.provider_type]).filter(Boolean) as string[];
        if (!tipos.some((t) => providerTypes.includes(t))) return false;
      }
      if (ageRange && !(p.age_ranges ?? []).includes(ageRange)) return false;
      if (modality && !(p.modalities ?? []).includes(modality)) return false;
      if (neuroaffirming && !p.neuroaffirming) return false;
      if (section && !(p.sections ?? []).includes(section)) return false;
      if (neuroCondition && !(p.neuro_conditions ?? []).includes(neuroCondition)) return false;
      if (city && p.city !== city) return false;
      if (center && radiusKm && p.latitude != null && p.longitude != null) {
        const dist = haversineKm(center, { lat: p.latitude, lng: p.longitude });
        if (dist > radiusKm) return false;
      }
      return true;
    });
    // Orden: VERIFICADOS primero, luego fundadores (SEO); después, si conocemos
    // la ubicación del visitante (`center`), por CERCANÍA ascendente; si no,
    // orden estable.
    //
    // «Verificada» lo calcula la vista: una cuenta real siempre lo está; una
    // ficha del directorio, sólo si alguien la reclamó o si el admin la
    // confirmó por fuera. Es lo que el correo de invitación promete: quien no
    // confirme queda por debajo de los perfiles verificados.
    const withDist = pass.map((p, i) => {
      const d = center && p.latitude != null && p.longitude != null
        ? haversineKm(center, { lat: p.latitude, lng: p.longitude })
        : Number.POSITIVE_INFINITY;
      return { p, i, d };
    });
    withDist.sort((a, b) =>
      (Number(b.p.verificada !== false) - Number(a.p.verificada !== false)) ||
      (Number(b.p.is_founder) - Number(a.p.is_founder)) ||
      (Number(b.p.is_donor) - Number(a.p.is_donor)) ||
      (center ? a.d - b.d : a.i - b.i));
    return withDist.map((x) => x.p);
  }, [providers, query, categoryId, specialty, productCategory, ageRange, modality, neuroaffirming, section, neuroCondition, city, center, radiusKm, anyOf, providerTypes]);

  return { providers, filtered, cities, loading, error, refetch };
}
