/**
 * AppLayout — marco de la app con navegación accesible.
 *
 * Header con marca y enlaces; en móvil, barra inferior con destinos principales.
 * La navegación se adapta al estado de sesión y al rol. Áreas táctiles ≥44px,
 * estado activo visible y labels claros (poca carga cognitiva).
 */
import { NavLink, Outlet, useNavigate, Link, useLocation } from 'react-router-dom';
import { useFotoPendiente } from '@/hooks/useFotoPendiente';
import { useSucursalesPendientes } from '@/hooks/useSucursalesPendientes';
import { Compass, LayoutDashboard, Settings, LogIn, LogOut, ShieldCheck, MessageCircleQuestion, School, GraduationCap, Grid3x3, X, BookOpenCheck, BookOpen, ShieldAlert, CalendarDays, ShoppingBag, MessageSquare, MessageCircle, Heart, Lightbulb, Award, Briefcase, Users, BadgeCheck, ClipboardList } from 'lucide-react';
import { Suspense, lazy, useEffect, useState, type ComponentType } from 'react';
import type { ReactNode } from 'react';
import { useTranslation } from 'react-i18next';
import logoHeaderUrl from '@/assets/logo-header.png';
import { useAuth } from '@/hooks/useAuth';
import { useMembership } from '@/hooks/useMembership';
import { Button, SkeletonCard, useToast } from '@/components/ui';
import type { AuthView } from '@/components/onboarding/AuthModals';
import { track } from '@/lib/track';
import { NotificationsBell } from '@/components/content/NotificationsBell';
import { NavMoreMenu } from '@/components/layout/NavMoreMenu';
import { useFounderAutoClaim, useFounderProgressNotice } from '@/hooks/useFounder';
import { useCampaign } from '@/hooks/useCampaign';
import { useCountry } from '@/stores/countryStore';
import { useAuthStore } from '@/stores/authStore';
import { useReferralCapture } from '@/hooks/useReferral';
import { useGeoPrefill } from '@/hooks/useGeoPrefill';
import { useMembershipGate } from '@/hooks/useMembershipGate';
import { useAppointmentReminders } from '@/hooks/useAppointmentRequests';

// ── Ventanas emergentes: fuera del bundle inicial ──────────────────────────
// Ninguna de estas se ve al abrir la portada, pero todas viajaban en index.js
// y había que descargarlas, analizarlas y ejecutarlas ANTES del primer pixel.
// Las dos más caras: AuthModals arrastraba react-hook-form + zod + todos los
// esquemas, y SocialOnboarding el catálogo de municipios de México (43 KB de
// fuente). Con React.lazy cada una se descarga el día que se abre.
//
// Todas se renderizan condicionalmente y envueltas en <Suspense fallback={null}>:
// mientras llega el chunk simplemente no hay modal, que es justo lo que había
// un instante antes.
// `lazyOptional`: para overlays NO críticos (video, popups, banners). Si el chunk
// falla al cargar —p. ej. un 404 tras un despliegue en el que no se subió todo el
// `assets/` o no se purgó el CDN— renderiza null en vez de propagar el error y
// tumbar TODA la app (antes: "Failed to fetch dynamically imported module"). Los
// modales FUNCIONALES (barrera de onboarding, portero de cuota, auth) siguen con
// `lazy` normal para que `vite:preloadError` recargue y tome el index nuevo.
function lazyOptional<T extends ComponentType<any>>(factory: () => Promise<{ default: T }>) {
  return lazy(() => factory().catch(() => ({ default: (() => null) as unknown as T })));
}

const WelcomeVideo = lazyOptional(() => import('@/components/onboarding/WelcomeVideo').then((m) => ({ default: m.WelcomeVideo })));
const AuthModals = lazy(() => import('@/components/onboarding/AuthModals').then((m) => ({ default: m.AuthModals })));
const SupportButton = lazyOptional(() => import('@/components/onboarding/SupportButton').then((m) => ({ default: m.SupportButton })));
const SocialOnboarding = lazy(() => import('@/components/onboarding/SocialOnboarding').then((m) => ({ default: m.SocialOnboarding })));
const FounderPopup = lazyOptional(() => import('@/components/onboarding/FounderPopup').then((m) => ({ default: m.FounderPopup })));
const FounderCongratsPopup = lazyOptional(() => import('@/components/onboarding/FounderCongratsPopup').then((m) => ({ default: m.FounderCongratsPopup })));
const GuidedTour = lazyOptional(() => import('@/components/onboarding/GuidedTour').then((m) => ({ default: m.GuidedTour })));
const WelcomePopup = lazyOptional(() => import('@/components/onboarding/WelcomePopup').then((m) => ({ default: m.WelcomePopup })));
const CampaignWelcomePopup = lazyOptional(() => import('@/components/campaign/CampaignWelcomePopup').then((m) => ({ default: m.CampaignWelcomePopup })));
const MembershipSuccessNotice = lazyOptional(() => import('@/components/membership/MembershipSuccessNotice').then((m) => ({ default: m.MembershipSuccessNotice })));
const SoftSignupBanner = lazyOptional(() => import('@/components/onboarding/SoftSignupBanner').then((m) => ({ default: m.SoftSignupBanner })));
const SurveyInviteBanner = lazyOptional(() => import('@/components/survey/SurveyInviteBanner').then((m) => ({ default: m.SurveyInviteBanner })));
const ReglamentoActualizado = lazyOptional(() => import('@/components/legal/ReglamentoActualizado').then((m) => ({ default: m.ReglamentoActualizado })));
const ReportModal = lazyOptional(() => import('@/components/report/ReportModal').then((m) => ({ default: m.ReportModal })));
const MembershipReminderPopup = lazyOptional(() => import('@/components/membership/MembershipReminderPopup').then((m) => ({ default: m.MembershipReminderPopup })));
const AccountInactiveModal = lazy(() => import('@/components/membership/AccountInactiveModal').then((m) => ({ default: m.AccountInactiveModal })));
const AccountReactivatedModal = lazy(() => import('@/components/membership/AccountReactivatedModal').then((m) => ({ default: m.AccountReactivatedModal })));
const SuspendedAccountModal = lazy(() => import('@/components/membership/SuspendedAccountModal').then((m) => ({ default: m.SuspendedAccountModal })));
const ImproveModal = lazyOptional(() => import('@/components/layout/ImproveModal').then((m) => ({ default: m.ImproveModal })));
import { setRefCode } from '@/hooks/useShop';
import { LanguageSwitcher } from './LanguageSwitcher';
import { SocialLinks } from './SocialLinks';
import { AccessibilityMenu } from './AccessibilityMenu';
import { NavPill } from './NavPill';
import { InstallAppButton } from '@/components/pwa/InstallAppButton';
import { cn } from '@/lib/utils';

const INTRO_KEY = 'neuro.introSeen';
const TOUR_KEY = 'neuro.tourSeen';

function NavItem({ to, icon, label }: { to: string; icon: ReactNode; label: string }) {
  return (
    <NavLink
      to={to}
      className={({ isActive }) =>
        cn(
          'flex flex-1 flex-col items-center justify-center gap-0.5 py-2 text-xs font-medium lg:flex-none lg:flex-row lg:gap-2 lg:px-3 lg:py-2 lg:text-sm',
          'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-500',
          isActive ? 'text-brand-700' : 'text-muted hover:text-slate-700',
        )
      }
    >
      {icon}
      {label}
    </NavLink>
  );
}

export function AppLayout() {
  // Sube la foto que quedó del registro, en el primer acceso.
  useFotoPendiente();
  useSucursalesPendientes();
  const { isAuthenticated, isAdmin, isAdvisor, role, fullName, signOut, needsOnboarding } = useAuth();
  const { t } = useTranslation();
  const toast = useToast();
  const navigate = useNavigate();
  const location = useLocation();

  // SEO: canónica dinámica POR RUTA. Sin esto, el `<link rel=canonical>` estático
  // de index.html (la portada) se aplicaría a TODAS las rutas de la SPA y Google
  // las trataría como duplicadas de la home. Aquí la fijamos a la URL actual
  // (origen + pathname, sin query) en cada cambio de página.
  useEffect(() => {
    const href = `${window.location.origin}${location.pathname}`;
    let link = document.querySelector<HTMLLinkElement>('link[rel="canonical"]');
    if (!link) {
      link = document.createElement('link');
      link.rel = 'canonical';
      document.head.appendChild(link);
    }
    link.href = href;
  }, [location.pathname]);

  // Perfil suspendido: bloquea con un aviso de reactivación al iniciar sesión.
  const suspendedAt = useAuthStore((s) => s.profile?.suspended_at ?? null);
  const suspendUntil = useAuthStore((s) => s.profile?.suspend_until ?? null);

  // Splash de video: una vez por navegador y SOLO en escritorio.
  //
  // En móvil cubría la pantalla en negro ~5 s en la primera visita: era la causa
  // del FCP de 4.4 s y el LCP de 5.1 s (la cadena de red era de solo 1.2 s).
  // Quien llega desde el teléfono —la mayoría— ve el sitio de inmediato; la
  // intro se conserva en pantallas grandes, donde la conexión suele ser mejor.
  const [showVideo, setShowVideo] = useState(() => {
    try {
      // Durante el prerender (react-snap) NO mostramos el splash: taparía la
      // portada en el HTML estático capturado.
      if (typeof navigator !== 'undefined' && navigator.userAgent === 'ReactSnap') return false;
      if (localStorage.getItem(INTRO_KEY) != null) return false;
      // Coincide con el breakpoint md de Tailwind (768px).
      const isDesktop =
        typeof window !== 'undefined' &&
        window.matchMedia('(min-width: 768px)').matches &&
        !window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      return isDesktop;
    } catch {
      return false;
    }
  });
  const [authView, setAuthView] = useState<AuthView>('none');
  // Durante el prerender (react-snap) NO se renderiza ningún emergente: si no,
  // react-snap los hornea en el HTML estático (en inglés y sin Supabase), y en
  // el cliente aparecen "pegados" y sin poder cerrarse. En el cliente real
  // (UA normal) esto es siempre false, así que todo funciona igual.
  const isPrerender = typeof navigator !== 'undefined' && navigator.userAgent === 'ReactSnap';
  const [showWelcome, setShowWelcome] = useState(false);
  // UI no crítica (banner de registro suave, botón flotante de soporte): sus
  // chunks se descargaban durante el primer pintado y entraban en la cadena
  // crítica del LCP (nodos SoftSignupBanner/SupportButton del árbol de red).
  // No se ven en el instante inicial, así que se montan cuando el navegador
  // queda ocioso; su descarga deja de competir con el héroe.
  const [deferUi, setDeferUi] = useState(false);
  // Guía rápida: se muestra una vez, tras el video de introducción.
  const [showTour, setShowTour] = useState(false);
  const [showFounder, setShowFounder] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);
  // Campaña de pre-registro: mientras esté activa se apagan el popup de fundadores
  // y el banner de registro suave (se reemplazan por el embudo de campaña).
  const { config: campaign, popupActiveFor } = useCampaign();
  // "Campaña activa" para efectos de RECEPCIÓN: muestra el popup de bienvenida de
  // campaña y SUPRIME el tour, el FounderPopup y el banner de registro suave.
  // Depende SOLO de `active` — el directorio se mantiene abierto por su propia
  // bandera (`directory_open`), que la cortina (`directoryLockedFor`) evalúa aparte.
  // Antes esto se acoplaba a `directory_open`, lo que al abrir el directorio dejaba
  // la recepción como "fuera de campaña" (sin popup de bienvenida y con el popup de
  // fundador duplicándose al cargar y al hacer scroll).
  const campaignActive = campaign?.active === true;
  const { country: selCountry } = useCountry();
  const profileCountry = useAuthStore((s) => s.profile?.country ?? null);
  const [showCampaignPopup, setShowCampaignPopup] = useState(false);
  const { status: memStatus, daysLeft: memDays } = useMembership();
  // Agenda y mensajes son funciones del cien por ciento: la agenda exige cuota
  // cubierta y responder mensajes exige además estar publicado, porque quien no
  // aparece en el directorio no recibe consultas de familias.
  const paidUntil = useAuthStore((st) => st.profile?.membership_paid_until ?? null);
  const publicado = useAuthStore((st) => st.profile?.is_published ?? false);
  const cuotaCubierta =
    memStatus === 'active' || memStatus === 'exempt' ||
    (!!paidUntil && new Date(paidUntil).getTime() > Date.now());
  const sinAgenda = isAuthenticated && !isAdmin && !isAdvisor && role === 'provider' && !cuotaCubierta;
  const sinMensajes = isAuthenticated && !isAdmin && !isAdvisor && role === 'provider' && (!cuotaCubierta || !publicado);
  // Detección automática de Miembro Fundador (reclama cupo si el usuario califica).
  const { justClaimed: founderJustClaimed } = useFounderAutoClaim();
  const [founderCongratsDismissed, setFounderCongratsDismissed] = useState(false);
  // Aviso al inicio de sesión con el % de cumplimiento de requisitos de Fundador.
  useFounderProgressNotice();
  // Captura ?ref= y atribuye la recomendación (programa Recomienda Neuromundi).
  useReferralCapture();
  // Prefill del país por IP (solo si no hay país elegido; el usuario puede cambiarlo).
  useGeoPrefill();
  // Recordatorios de cita 24 h antes (fallback del cliente para el destinatario).
  useAppointmentReminders();
  const [reportOpen, setReportOpen] = useState(false);
  const [improveOpen, setImproveOpen] = useState(false);
  // Cuenta inactiva por cuota sin cubrir: apaga el panel y explica con cordialidad.
  const { blocked, justReactivated, dismissReactivated } = useMembershipGate();
  const [gateOpen, setGateOpen] = useState(false);
  const showMemberBanner =
    isAuthenticated && !isAdmin && (memStatus === 'pending' || memStatus === 'past_due');

  // Marca el intro como VISTO en cuanto se muestra (no solo al terminarlo). Si el
  // service worker se actualiza a mitad del video tras un despliegue, `main.tsx`
  // recarga; sin esta marca temprana el video se reproduciría de nuevo.
  useEffect(() => {
    if (!showVideo) return;
    try { localStorage.setItem(INTRO_KEY, '1'); } catch { /* almacenamiento no disponible */ }
  }, [showVideo]);

  // Embudo de campaña: tras el video de intro (o directo si ya se vio), muestra el
  // popup de bienvenida UNA vez por sesión, solo si el admin lo activó para el
  // continente del visitante. Admin y asesor no lo necesitan pero no molesta.
  useEffect(() => {
    if (showVideo || !campaignActive) return;
    const country = profileCountry ?? selCountry ?? null;
    if (!popupActiveFor(country)) return;
    try {
      if (sessionStorage.getItem('neuro.campaignPopup')) return;
      sessionStorage.setItem('neuro.campaignPopup', '1');
    } catch { /* noop */ }
    // Se DIFIERE a que el navegador quede ocioso tras la carga: si el popup
    // aparece durante el pintado inicial, su irrupción cuenta como desplazamiento
    // (CLS) en la medición de Lighthouse —era el mayor causante de CLS en móvil—.
    // Mostrarlo tras la carga lo saca de esa ventana sin perder el embudo.
    const w = window as Window & { requestIdleCallback?: (cb: () => void, o?: { timeout: number }) => number };
    const show = () => setShowCampaignPopup(true);
    const schedule = () => { if (w.requestIdleCallback) w.requestIdleCallback(show, { timeout: 4000 }); else setTimeout(show, 2500); };
    let t: number | undefined;
    if (document.readyState === 'complete') t = window.setTimeout(schedule, 2000);
    else window.addEventListener('load', () => { t = window.setTimeout(schedule, 2000); }, { once: true });
    return () => { if (t) window.clearTimeout(t); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showVideo, campaignActive, profileCountry, selCountry, campaign]);

  const dismissVideo = () => {
    try {
      localStorage.setItem(INTRO_KEY, '1');
    } catch {
      /* almacenamiento no disponible */
    }
    setShowVideo(false);
    // Al terminar el video, ofrecemos la guía rápida (solo la primera vez). Durante
    // la campaña se omite: el embudo de bienvenida toma su lugar.
    try {
      if (!campaignActive && localStorage.getItem(TOUR_KEY) == null) setShowTour(true);
    } catch { /* noop */ }
  };

  const closeTour = () => {
    try { localStorage.setItem(TOUR_KEY, '1'); } catch { /* noop */ }
    setShowTour(false);
    // Al cerrar el tour, ofrecemos de inmediato el popup de Miembro Fundador
    // (mismas condiciones que por scroll: sin sesión y no descartado en 24h).
    if (isAuthenticated) return;
    try {
      const ts = Number(localStorage.getItem('neuro.founderPopup') || 0);
      if (ts && Date.now() - ts < 24 * 60 * 60 * 1000) return;
    } catch { /* noop */ }
    setShowFounder(true);
  };

  // Guía rápida para quien no está viendo el video: o ya lo vio en una visita
  // anterior, o entró desde móvil (donde el splash no se reproduce).
  //
  // Se APLAZA a propósito: montarla durante la carga inicial metía su DOM y su
  // trabajo en el momento más caro de la página (subió el TBT de 30 a 160 ms).
  // Esperamos a que el navegador quede ocioso; además da tiempo a que la
  // persona vea el sitio antes de que le aparezca un modal encima.
  useEffect(() => {
    if (showVideo) return;
    let cancelled = false;
    const offer = () => {
      if (cancelled) return;
      try {
        if (!campaignActive && localStorage.getItem(TOUR_KEY) == null) setShowTour(true);
      } catch { /* noop */ }
    };
    const w = window as Window & { requestIdleCallback?: (cb: () => void, o?: { timeout: number }) => number };
    const id = w.requestIdleCallback
      ? w.requestIdleCallback(offer, { timeout: 4000 })
      : window.setTimeout(offer, 2500);
    return () => {
      cancelled = true;
      if (!w.requestIdleCallback) window.clearTimeout(id);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showVideo]);

  // Monta la UI no crítica cuando el navegador queda ocioso (o, como respaldo,
  // 2 s después). Así sus chunks no viajan en la ventana del LCP.
  useEffect(() => {
    const w = window as Window & { requestIdleCallback?: (cb: () => void, o?: { timeout: number }) => number };
    const run = () => setDeferUi(true);
    const id = w.requestIdleCallback ? w.requestIdleCallback(run, { timeout: 3000 }) : window.setTimeout(run, 2000);
    return () => { if (!w.requestIdleCallback && typeof id === 'number') window.clearTimeout(id); };
  }, []);

  // Captura el código de afiliado (?ref=CODE) para aplicarlo en la compra.
  useEffect(() => {
    const ref = new URLSearchParams(window.location.search).get('ref');
    if (ref) setRefCode(ref);
  }, []);

  // Errores de OAuth (Google/LinkedIn/Microsoft): cuando el proveedor rechaza el
  // inicio de sesión, Supabase regresa con `error`/`error_description` en el hash
  // (o en la query) SIN crear sesión. Antes esto se veía como "se abre y se
  // cierra de golpe" sin nada en consola. Aquí lo leemos, lo mostramos y
  // limpiamos la URL para que no reaparezca al recargar.
  useEffect(() => {
    try {
      const hashParams = new URLSearchParams((window.location.hash || '').replace(/^#/, ''));
      const queryParams = new URLSearchParams(window.location.search || '');
      const err = hashParams.get('error') || queryParams.get('error');
      if (!err) return;
      const desc =
        hashParams.get('error_description') ||
        queryParams.get('error_description') ||
        err;
      // Log explícito para diagnóstico + aviso visible al usuario.
      console.error('[OAuth]', err, '·', desc);
      toast.error(decodeURIComponent(desc.replace(/\+/g, ' ')));
      // Limpia error de la URL (conserva la ruta).
      window.history.replaceState(null, '', window.location.pathname);
    } catch {
      /* nada que hacer */
    }
  }, [toast]);

  // Bienvenida (1 sola vez): al volver del enlace de confirmación del correo
  // (Supabase añade `type=signup` al hash) o si quedó marcada al registrarse.
  useEffect(() => {
    const WELCOMED = 'neuromundi.welcomed';
    const PENDING = 'neuromundi.pendingWelcome';
    try {
      if (localStorage.getItem(WELCOMED) === '1') return;
      const hash = window.location.hash || '';
      const fromConfirm = /type=signup/.test(hash);
      const pending = localStorage.getItem(PENDING) === '1';
      if (fromConfirm || (pending && isAuthenticated)) {
        setShowWelcome(true);
        localStorage.setItem(WELCOMED, '1');
        localStorage.removeItem(PENDING);
      }
    } catch {
      /* almacenamiento no disponible */
    }
  }, [isAuthenticated, needsOnboarding]);

  // Popup "Miembro Fundador": para VISITANTES sin sesión, al primer scroll.
  // Si se cierra, no reaparece por 24h (localStorage).
  useEffect(() => {
    if (isAuthenticated) return;
    const KEY = 'neuro.founderPopup';
    try {
      const ts = Number(localStorage.getItem(KEY) || 0);
      if (ts && Date.now() - ts < 24 * 60 * 60 * 1000) return;
    } catch { /* noop */ }
    let shown = false;
    const onScroll = () => {
      if (shown || window.scrollY < 8) return;
      shown = true;
      window.removeEventListener('scroll', onScroll);
      setShowFounder(true);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, [isAuthenticated]);

  const closeFounder = (reason: 'cta' | 'later' | 'close') => {
    setShowFounder(false);
    try { localStorage.setItem('neuro.founderPopup', String(Date.now())); } catch { /* noop */ }
    if (reason !== 'cta') track('founder_popup_dismiss', { via: reason });
  };

  // El registro YA NO se abre solo al cargar (era intrusivo). Aparece por
  // intención (al intentar una acción que lo requiere) y, como recordatorio
  // suave, mediante un banner inferior una vez por sesión (ver SoftSignupBanner).

  // Si el usuario ya tiene sesión pero su cuota está pendiente o vencida, le
  // mostramos el modal de pago una vez por sesión (también tras iniciar sesión).
  useEffect(() => {
    if (showVideo || authView !== 'none' || isAdmin) return;
    if (memStatus !== 'pending' && memStatus !== 'past_due') return;
    try {
      if (sessionStorage.getItem('neuro.memPrompted') != null) return;
      sessionStorage.setItem('neuro.memPrompted', '1');
    } catch {
      /* noop */
    }
    setAuthView('membership');
  }, [showVideo, authView, memStatus, isAdmin]);

  // Aviso de cuenta inactiva: una vez por sesión, sin acosar al usuario.
  useEffect(() => {
    if (!blocked) return;
    try {
      if (sessionStorage.getItem('neuro.gatePrompted') != null) return;
      sessionStorage.setItem('neuro.gatePrompted', '1');
    } catch {
      /* noop */
    }
    setGateOpen(true);
  }, [blocked]);

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  // BARRERA OBLIGATORIA: si el usuario entró por login social y aún no completó
  // su perfil, la app NO se renderiza. Solo puede completar el registro o salir.
  if (needsOnboarding) {
    return (
      <Suspense fallback={null}>
        <SocialOnboarding />
      </Suspense>
    );
  }

  return (
    <div className="min-h-screen bg-surface">
      {/* Todo lo emergente va aquí, perezoso y condicionado: nada de esto se ve
          en el primer pintado, así que tampoco tiene por qué descargarse antes.
          El fallback es `null` a propósito — un spinner de un modal que aún no
          existe sería ruido. */}
      <Suspense fallback={null}>
        {!isPrerender && showVideo && <WelcomeVideo onDone={dismissVideo} />}
        {!isPrerender && showWelcome && <WelcomePopup onClose={() => setShowWelcome(false)} />}
        {/* Tour guiado DESACTIVADO por decisión de producto. Para reactivarlo,
            vuelve a poner `showTour &&` aquí. */}
        {false && !isPrerender && showTour && <GuidedTour onClose={closeTour} />}
        {!isPrerender && showCampaignPopup && (
          <CampaignWelcomePopup
            onClose={() => setShowCampaignPopup(false)}
            onSeeBenefits={() => { setShowCampaignPopup(false); navigate('/beneficios'); }}
          />
        )}
        {!isPrerender && typeof window !== 'undefined' && window.location.search.includes('membership=') && <MembershipSuccessNotice />}
        {/* El popup de fundadores SÍ aparece durante la campaña (la campaña busca
            atraer fundadores). Solo se evita que se encime con el de bienvenida:
            sale tras cerrar ese. */}
        {!isPrerender && showFounder && !showCampaignPopup && <FounderPopup onClose={closeFounder} />}
        {!isPrerender && founderJustClaimed && !founderCongratsDismissed && (
          <FounderCongratsPopup onClose={() => setFounderCongratsDismissed(true)} />
        )}
        {isAuthenticated && suspendedAt && (
          <SuspendedAccountModal
            until={suspendUntil}
            onExit={async () => { await signOut(); navigate('/'); }}
          />
        )}
        {isAuthenticated && <MembershipReminderPopup />}
        {reportOpen && <ReportModal onClose={() => setReportOpen(false)} />}
        {improveOpen && <ImproveModal onClose={() => setImproveOpen(false)} />}
        {gateOpen && blocked && (
          <AccountInactiveModal open onClose={() => setGateOpen(false)} />
        )}
        {justReactivated && (
          <AccountReactivatedModal
            open
            onClose={dismissReactivated}
            onGoToPanel={() => { dismissReactivated(); navigate('/panel'); }}
          />
        )}
        {/* Se monta solo cuando hay un modal de acceso abierto: así el chunk con
            react-hook-form + zod se descarga al pulsar "Entrar", no al llegar. */}
        {authView !== 'none' && (
          <AuthModals view={authView} onChangeView={setAuthView} onAuthenticated={() => navigate('/panel')} />
        )}
        {deferUi && !campaignActive && <SoftSignupBanner onSignup={() => navigate('/crear-cuenta')} />}
        {/* Invitación a la Encuesta Internacional: solo con sesión + perfil completo,
            una vez por sesión; se apaga al responderla (ver SurveyInviteBanner). */}
        {deferUi && <SurveyInviteBanner onRespond={() => navigate('/encuesta')} />}
        {/* Re-aceptacion del reglamento cuando cambia la version vigente
            (auditoria 15 oct 2026, M-18). No bloquea la navegacion. */}
        {deferUi && <ReglamentoActualizado />}
      </Suspense>
      <header className="sticky top-0 z-30 border-b border-slate-100 bg-[#eefbfa]/95 backdrop-blur">
        <div className="mx-auto max-w-6xl px-4 py-2">
          {/* flex-wrap + gap-x fijo: si el logo y la navegación no caben en una
              línea, la barra baja a la siguiente en vez de solaparse con el
              logo. El gap nunca es negativo, así que NUNCA se montan encima
              (el bug de "logo detrás del botón" venía de justify-between con
              espacio negativo en anchos intermedios). El logo no se encoge. */}
          <div className="flex flex-wrap items-center justify-between gap-x-4 gap-y-1">
            <NavLink to="/" className="inline-flex shrink-0 items-center gap-2 leading-none">
              <img
                src={logoHeaderUrl}
                alt=""
                width={48}
                height={48}
                decoding="async"
                className="h-11 w-11 shrink-0 object-contain"
              />
              <span className="inline-flex flex-col">
                <span className="text-[1.6875rem] font-extrabold text-[#8C6D1F]">{t('common.appName')}</span>
                <span className="mt-0.5 block w-full whitespace-nowrap text-center text-[0.66rem] font-semibold tracking-[0.04em] text-[#1e3a5f]">
                  {t('common.tagline')}
                </span>
              </span>
            </NavLink>
            {/* Controles siempre visibles en móvil: accesibilidad (control visual) e idioma. */}
            <div className="flex items-center gap-1 lg:hidden">
              {isAuthenticated && fullName && (
                <span className="mr-1 max-w-[6.5rem] truncate text-sm text-muted">{t('nav.greeting', { name: fullName.split(' ')[0] })}</span>
              )}
              <AccessibilityMenu />
              <LanguageSwitcher />
            </div>
            {/* Barra única (escritorio): a lo ancho, en su propia fila. A la
                izquierda los enlaces de sección; a la derecha, EN LA MISMA barra,
                los controles de cuenta (dona, notificaciones, accesibilidad,
                idioma, entrar). w-full la fuerza a su propia línea bajo el logo. */}
            <nav className="hidden w-full min-w-0 flex-wrap items-center gap-x-2 gap-y-1.5 lg:flex" aria-label={t('nav.directory')}>
              {/* Enlaces principales */}
              <NavPill to="/kit" label={t('nav.kit')} colorClass="bg-gradient-to-br from-brand-500 via-brand-600 to-brand-800" />
              <NavPill to="/directorio" label={t('nav.directory')} colorClass="bg-brand-600" />
              <NavPill to="/inclusion-escolar" label={t('nav.school')} colorClass="bg-gradient-to-br from-amber-600 via-orange-500 to-rose-500" />
              <NavPill to="/academy" label={t('lms.tab')} colorClass="bg-gradient-to-br from-brand-600 via-brand-500 to-evs-5" />
              <NavPill to="/blog" label={t('nav.blog')} colorClass="bg-gradient-to-br from-brand-600 via-indigo-600 to-indigo-800" />
              <NavPill to="/eventos" label={t('nav.events')} colorClass="bg-gradient-to-br from-indigo-600 via-indigo-700 to-brand-700" />
              <NavPill to="/tienda" label={t('shop.title')} colorClass="bg-gradient-to-br from-fuchsia-600 via-purple-600 to-indigo-600" />
              {/* Secundarios agrupados para no saturar la barra */}
              <NavMoreMenu
                label={t('nav.more')}
                items={[
                  { to: '/inclusion-laboral', label: t('nav.labor'), icon: <Briefcase className="h-4 w-4" /> },
                  { to: '/tribu', label: t('nav.tribe'), icon: <Users className="h-4 w-4" /> },
                  { to: '/red', label: t('nav.red'), icon: <BadgeCheck className="h-4 w-4" /> },
                  { to: '/fundadores', label: t('nav.founders'), icon: <Award className="h-4 w-4" /> },
                  { to: '/donantes', label: t('nav.donors'), icon: <Heart className="h-4 w-4" /> },
                  // La encuesta se promete a TODOS los perfiles en el correo de
                  // invitación («participación prioritaria en la 1.ª Encuesta
                  // sobre la Situación Neurológica Mundial») y no tenía puerta:
                  // su única entrada era un cartel que exige sesión y alta
                  // completa, aunque la encuesta es pública y anónima por
                  // diseño. (Auditoría del 15 oct 2026, hallazgo A-8.)
                  { to: '/encuesta', label: t('nav.survey'), icon: <ClipboardList className="h-4 w-4" /> },
                  // El curso de bienvenida y la búsqueda transversal existían y
                  // no estaban enlazados desde ninguna parte. (Hallazgo M-6.)
                  { to: '/curso-bienvenida', label: t('nav.welcomeCourse'), icon: <GraduationCap className="h-4 w-4" /> },
                  { to: '/proteccion-datos', label: t('nav.dataProtection'), icon: <ShieldCheck className="h-4 w-4" /> },
                  { to: '/pregunta-al-experto', label: t('nav.askExpert'), icon: <MessageCircleQuestion className="h-4 w-4" /> },
                ]}
              />
              {/* Panel del usuario fusionado en la misma fila para ahorrar una
                  tira de altura. Separador visual para distinguir los enlaces de
                  cuenta de los públicos; fluye/envuelve junto con los demás. */}
              {isAuthenticated && (
                <>
                  <span className="mx-1 hidden h-6 w-px bg-slate-200 lg:block" aria-hidden="true" />
                  <NavPill to="/panel" label={t('nav.dashboard')} colorClass="bg-slate-700" />
                  <NavPill to="/calendario" label={t('nav.calendar')} colorClass="bg-slate-600" disabled={sinAgenda} onDisabledClick={() => setGateOpen(true)} />
                  <NavPill to="/mensajes" label={t('nav.messages')} colorClass="bg-slate-600" disabled={sinMensajes} onDisabledClick={() => setGateOpen(true)} />
                  {/* Mi Perfil sigue accesible: ahí puede pagar y gestionar su cuenta. */}
                  <NavPill to="/ajustes" label={t('nav.settings')} colorClass="bg-slate-600" />
                </>
              )}
              {/* Controles de cuenta: fluyen en la MISMA barra, tras el último
                  enlace (Mi Perfil si hay sesión; si no, Más). Agrupados en un div
                  para que envuelvan juntos y se vea ordenado. */}
              <span className="mx-1 hidden h-6 w-px bg-slate-200 lg:block" aria-hidden="true" />
              <div className="flex items-center gap-x-1.5">
                <NavLink
                  to="/donar"
                  className="inline-flex items-center gap-1.5 rounded-full bg-[#8C6D1F] px-3 py-1.5 text-[13px] font-semibold text-white shadow-sm transition-colors hover:bg-[#75591a] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#8C6D1F] focus-visible:ring-offset-2"
                >
                  <Heart className="h-3.5 w-3.5" aria-hidden="true" /> {t('nav.donate')}
                </NavLink>
                {isAuthenticated && <NotificationsBell />}
                <AccessibilityMenu />
                <LanguageSwitcher />
                {isAuthenticated ? (
                  <Button size="sm" variant="ghost" onClick={handleSignOut} leadingIcon={<LogOut className="h-4 w-4" />}>
                    {t('nav.logout')}
                  </Button>
                ) : (
                  <Button size="sm" onClick={() => navigate('/crear-cuenta')} leadingIcon={<LogIn className="h-4 w-4" />}>
                    {t('nav.login')}
                  </Button>
                )}
              </div>
            </nav>
          </div>
        </div>
      </header>

      {showMemberBanner && (
        <div
          role="status"
          className={cn(
            'flex flex-wrap items-center justify-center gap-x-3 gap-y-1 px-4 py-2 text-center text-sm',
            memStatus === 'past_due' ? 'bg-evs-1/10 text-evs-1' : 'bg-warm-100 text-warm-800',
          )}
        >
          <span>
            {memStatus === 'past_due'
              ? t('membership.bannerPastDue')
              : t('membership.bannerPending', { days: memDays ?? 7 })}
          </span>
          <button
            type="button"
            onClick={() => setAuthView('membership')}
            className="font-semibold underline hover:no-underline"
          >
            {t('membership.bannerCta')}
          </button>
        </div>
      )}

      <main className="pb-20 lg:pb-0">
        <Suspense
          fallback={
            <div className="mx-auto max-w-2xl p-4" aria-busy="true">
              <SkeletonCard rows={2} />
            </div>
          }
        >
          <Outlet />
        </Suspense>
      </main>

      <footer className="border-t border-slate-100 px-4 pt-4 pb-24 text-center text-sm text-muted lg:pb-6">
        <p className="mb-3 font-semibold text-slate-700">{t('followUs.title')}</p>
        <SocialLinks className="mb-4" />
        {/* Instalar app: va JUSTO debajo de las redes, en la parte alta del pie,
            para que la barra inferior fija de móvil no lo tape (al final del pie
            sí quedaba cubierto). Devuelve null si no se puede instalar. */}
        <div className="mb-5 flex justify-center">
          <InstallAppButton />
        </div>
        {campaign?.whatsapp_url && (
          <div className="mb-5 flex justify-center">
            <a
              href={campaign.whatsapp_url}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-full bg-[#0b8043] px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-[#0a6d39] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0b8043] focus-visible:ring-offset-2"
            >
              <MessageCircle className="h-4 w-4" aria-hidden="true" /> {t('footer.whatsappChannel')}
            </a>
          </div>
        )}
        {/* Texto visible descriptivo (no "Conocer más" a secas): la auditoría SEO
            de enlaces evalúa el texto visible, no el aria-label. */}
        <Link to="/conocer-mas" className="hover:text-brand-700">{t('info.title')}</Link>
        <span className="mx-2">·</span>
        <Link to="/proteccion-datos" className="hover:text-brand-700">{t('nav.dataProtection')}</Link>
        <span className="mx-2">·</span>
        <Link to="/privacy" className="hover:text-brand-700">{t('auth.privacy')}</Link>
        <span className="mx-2">·</span>
        <Link to="/terms" className="hover:text-brand-700">{t('auth.terms')}</Link>
        <span className="mx-2">·</span>
        <Link to="/support" className="hover:text-brand-700">{t('support.pageTitle')}</Link>
        <span className="mx-2">·</span>
        <Link to="/manifiesto" className="hover:text-brand-700">{t('footer.manifesto')}</Link>
        <span className="mx-2">·</span>
        <Link to="/fundadores" className="hover:text-brand-700">{t('nav.founders')}</Link>
        <span className="mx-2">·</span>
        <Link to="/donantes" className="hover:text-brand-700">{t('nav.donors')}</Link>
        <span className="mx-2">·</span>
        <Link to="/encuesta" className="hover:text-brand-700">{t('nav.survey')}</Link>
        <span className="mx-2">·</span>
        <Link to="/verificados" className="hover:text-brand-700">{t('registry.title')}</Link>
        <span className="mx-2">·</span>
        <Link to="/donar" className="font-semibold text-[#6f5314] hover:underline">{t('nav.donate')}</Link>
        <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
          <button
            type="button"
            onClick={() => setReportOpen(true)}
            className="inline-flex items-center gap-1.5 rounded-full bg-red-600 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-red-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-red-500 focus-visible:ring-offset-2"
          >
            <ShieldAlert className="h-4 w-4" aria-hidden="true" /> {t('report.footerButton')}
          </button>
          <button
            type="button"
            onClick={() => setImproveOpen(true)}
            className="inline-flex items-center gap-1.5 rounded-full border border-green-300 bg-green-100 px-4 py-2 text-sm font-semibold text-green-800 transition-colors hover:bg-green-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-green-500 focus-visible:ring-offset-2"
          >
            <Lightbulb className="h-4 w-4" aria-hidden="true" /> {t('improve.footerButton')}
          </button>
        </div>
      </footer>

      {/* Barra inferior móvil */}
      {/* Hoja "Más" (solo móvil): opciones que no caben en la barra inferior. */}
      {moreOpen && (
        <div className="fixed inset-0 z-40 lg:hidden" role="dialog" aria-modal="true" aria-label={t('nav.more')}>
          <div className="absolute inset-0 bg-slate-900/40" onClick={() => setMoreOpen(false)} />
          <div className="absolute inset-x-0 bottom-0 max-h-[85dvh] overflow-y-auto overscroll-contain rounded-t-3xl bg-white p-4 pb-24 shadow-2xl">
            <div className="mb-2 flex items-center justify-between">
              <h2 className="text-base font-bold text-slate-900">{t('nav.more')}</h2>
              <button type="button" onClick={() => setMoreOpen(false)} aria-label={t('common.close')} className="rounded-full p-1 text-slate-500 hover:bg-slate-100">
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="grid grid-cols-3 gap-3">
              {[
                { to: '/kit', icon: <BookOpenCheck className="h-6 w-6" />, label: t('nav.kit'), color: 'bg-gradient-to-br from-brand-500 via-brand-600 to-brand-800' },
                { to: '/proteccion-datos', icon: <ShieldCheck className="h-6 w-6" />, label: t('nav.dataProtection'), color: 'bg-teal-600' },
                { to: '/pregunta-al-experto', icon: <MessageCircleQuestion className="h-6 w-6" />, label: t('nav.askExpert'), color: 'bg-cyan-600' },
                { to: '/inclusion-escolar', icon: <School className="h-6 w-6" />, label: t('school.title'), color: 'bg-gradient-to-br from-amber-600 via-orange-500 to-rose-500' },
                { to: '/inclusion-laboral', icon: <Briefcase className="h-6 w-6" />, label: t('nav.labor'), color: 'bg-gradient-to-br from-slate-600 to-slate-800' },
                { to: '/tribu', icon: <Users className="h-6 w-6" />, label: t('nav.tribe'), color: 'bg-gradient-to-br from-violet-600 to-fuchsia-600' },
                { to: '/red', icon: <BadgeCheck className="h-6 w-6" />, label: t('nav.red'), color: 'bg-gradient-to-br from-sky-600 to-cyan-600' },
                { to: '/academy', icon: <GraduationCap className="h-6 w-6" />, label: t('lms.tab'), color: 'bg-gradient-to-br from-brand-600 via-brand-500 to-evs-5' },
                { to: '/blog', icon: <BookOpen className="h-6 w-6" />, label: t('nav.blog'), color: 'bg-gradient-to-br from-brand-600 via-indigo-600 to-indigo-800' },
                { to: '/eventos', icon: <CalendarDays className="h-6 w-6" />, label: t('nav.events'), color: 'bg-gradient-to-br from-indigo-600 via-indigo-700 to-brand-700' },
                ...(isAuthenticated ? [{ to: '/calendario', icon: <CalendarDays className="h-6 w-6" />, label: t('nav.calendar'), color: 'bg-slate-600' }] : []),
                ...(isAuthenticated ? [{ to: '/mensajes', icon: <MessageSquare className="h-6 w-6" />, label: t('nav.messages'), color: 'bg-slate-600' }] : []),
                { to: '/tienda', icon: <ShoppingBag className="h-6 w-6" />, label: t('shop.title'), color: 'bg-gradient-to-br from-fuchsia-600 via-purple-600 to-indigo-600' },
                { to: '/fundadores', icon: <Award className="h-6 w-6" />, label: t('nav.founders'), color: 'bg-gradient-to-br from-brand-600 to-brand-800' },
                { to: '/donar', icon: <Heart className="h-6 w-6" />, label: t('nav.donate'), color: 'bg-[#8C6D1F]' },
              ].map((it) => (
                <button
                  key={it.to}
                  type="button"
                  onClick={() => { setMoreOpen(false); navigate(it.to); }}
                  className={`flex flex-col items-center gap-2 rounded-2xl p-4 text-xs font-semibold text-white shadow-sm transition-all duration-200 hover:brightness-110 active:scale-95 active:brightness-95 ${it.color}`}
                >
                  <span>{it.icon}</span>
                  {it.label}
                </button>
              ))}
            </div>
            {/* Instalar app: en el pie queda debajo de la barra inferior fija y
                no se alcanza en móvil. Aquí, en el menú "Más", es accesible. Solo
                se pinta si de verdad se puede instalar (el componente devuelve
                null en caso contrario), así que no ocupa espacio de más. */}
            <div className="mt-4 flex justify-center border-t border-slate-100 pt-4">
              <InstallAppButton />
            </div>
            <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-4">
              <LanguageSwitcher />
              <AccessibilityMenu />
            </div>
            <div className="mt-4 border-t border-slate-100 pt-4">
              <p className="mb-3 text-center text-sm font-semibold text-slate-700">{t('followUs.title')}</p>
              <SocialLinks />
            </div>
          </div>
        </div>
      )}

      <nav
        className="fixed inset-x-0 bottom-0 z-30 flex border-t border-slate-100 bg-white lg:hidden"
        aria-label={t('nav.dashboard')}
      >
        <NavItem to="/directorio" icon={<Compass className="h-5 w-5" />} label={t('nav.directory')} />
        <NavItem to="/pregunta-al-experto" icon={<MessageCircleQuestion className="h-5 w-5" />} label={t('nav.askExpert')} />
        <button
          type="button"
          onClick={() => setMoreOpen(true)}
          className="flex flex-1 flex-col items-center justify-center gap-0.5 py-2 text-xs font-medium text-muted hover:text-slate-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-500"
        >
          <Grid3x3 className="h-5 w-5" />
          {t('nav.more')}
        </button>
        {isAuthenticated ? (
          <>
            <NavItem to="/panel" icon={<LayoutDashboard className="h-5 w-5" />} label={t('nav.dashboard')} />
            <NavItem to="/ajustes" icon={<Settings className="h-5 w-5" />} label={t('nav.settings')} />
          </>
        ) : (
          <button
            type="button"
            onClick={() => navigate('/crear-cuenta')}
            className="flex flex-1 flex-col items-center justify-center gap-0.5 py-2 text-xs font-medium text-muted hover:text-slate-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-500"
          >
            <LogIn className="h-5 w-5" />
            {t('nav.login')}
          </button>
        )}
      </nav>

      {deferUi && (
        <Suspense fallback={null}>
          <SupportButton />
        </Suspense>
      )}
    </div>
  );
}
