/**
 * NotificationsBell — campana en el header con contador de no leídas y un panel
 * desplegable. Para el logro de 3 estrellas muestra el informe de cuántas
 * personas consultaron la publicación.
 */
import { useEffect, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import { Bell, Trophy, Award, CalendarClock, Megaphone, MessageSquare, Users, Gift, HandCoins, Compass, PauseCircle, AlertTriangle, Briefcase, Ticket, MailOpen } from 'lucide-react';
import { useNotifications } from '@/hooks/useNotifications';
import { notifDestino } from '@/lib/notificationPrefs';
import { useAvisarResultado } from '@/hooks/useAvisarResultado';

export function NotificationsBell() {
  const { t } = useTranslation();
  const { items, unreadCount, markRead, markAllRead } = useNotifications();
  const navigate = useNavigate();
  const avisar = useAvisarResultado();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', onClick);
    return () => document.removeEventListener('mousedown', onClick);
  }, []);

  return (
    <div className="relative" ref={ref}>
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="relative rounded-full p-2 text-slate-600 hover:bg-slate-100"
        aria-label={t('notif.title')}
      >
        <Bell className="h-5 w-5" />
        {unreadCount > 0 && (
          <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-evs-1 px-1 text-[10px] font-bold text-white">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>

      {open && (
        <div className="absolute right-0 z-50 mt-2 max-h-96 w-80 overflow-y-auto rounded-2xl border border-slate-100 bg-white p-2 shadow-xl">
          <div className="flex items-center justify-between px-2 py-1">
            <span className="text-sm font-semibold text-slate-900">{t('notif.title')}</span>
            {unreadCount > 0 && (
              <button type="button" onClick={() => void avisar(markAllRead())} className="text-xs text-brand-700 hover:underline">
                {t('notif.markAll')}
              </button>
            )}
          </div>

          {items.length === 0 ? (
            <p className="px-2 py-6 text-center text-sm text-muted">{t('notif.empty')}</p>
          ) : (
            <ul className="space-y-1">
              {items.map((n) => {
                const isAchievement = n.type === 'post_achievement';
                const isBadge = n.type === 'badge';
                const count = Number((n.data as { count?: number })?.count ?? 0);
                const isAppt = n.type.startsWith('appt_');
                const isMsg = n.type === 'admin_message';
                const isDM = n.type === 'direct_message';
                const isBooking = n.type === 'booking_request';
                const isWaitSlot = n.type === 'waitlist_slot';
                const isWaitJoin = n.type === 'waitlist_join';
                const isCampaign = n.type === 'campaign';
                const isReferral = n.type === 'referral_use' || n.type === 'referral_reward';
                const isCommission = n.type === 'commission_paid';
                const isDirMatch = n.type === 'directory_match';
                const isSuspReminder = n.type === 'suspension_reminder';
                const isCosto = n.type === 'account_costo';
                const isTopicJob = n.type === 'topic_job';
                const isTopicVenue = n.type === 'topic_venue';
                const isForumNew = n.type === 'forum_new';
                const isForumPending = n.type === 'forum_pending';
                const isForumApproved = n.type === 'forum_approved';
                const isForumModCall = n.type === 'forum_mod_call';
                const isForumModApproved = n.type === 'forum_mod_approved';
                const isForum = isForumNew || isForumPending || isForumApproved || isForumModCall || isForumModApproved;
                const isInviteOpen = n.type === 'invite_opened';
                const invOpenName = ((n.data ?? {}) as { nombre?: string }).nombre || '';
                const isGrace = n.type === 'directory_grace';
                const graceDays = ((n.data ?? {}) as { days_left?: number }).days_left ?? 0;
                const graceTitle = graceDays > 0 ? t('notif.grace.title') : t('notif.grace.final.title');
                const graceBody = graceDays > 0 ? t('notif.grace.body', { days: graceDays }) : t('notif.grace.final.body');
                const fd = (n.data ?? {}) as { title?: string; country?: string };
                const td = (n.data ?? {}) as { opportunity_type?: string; title?: string; name?: string; country?: string; city?: string };
                const tPlace = [td.city, td.country].filter(Boolean).join(', ');
                const ad = (n.data ?? {}) as { specialist_name?: string; recipient_name?: string; reason?: string; title?: string; from_name?: string };
                const apptSuffix = n.type.replace('appt_', '');
                // Los tipos creados por las migraciones recientes no estaban en
                // esta cadena, así que se pintaban con el texto literal de la
                // fila, escrito en español dentro del SQL: en coreano se leía
                // "Su perfil dejó de aparecer en el directorio". Ahora se
                // traduce por clave de tipo, y el texto de la fila queda sólo
                // como último recurso. (Auditoría 15 oct 2026, hallazgo M-7.)
                // Los huecos del aviso (fecha, motivo, nombre) viajan en `data`,
                // no dentro del texto: así la frase se traduce y el dato se
                // conserva. El texto de la fila queda de último recurso.
                // (Auditoría 15 oct 2026, hallazgo M-7; migración 0246.)
                const huecos = (n.data ?? {}) as Record<string, unknown>;
                const apptTitle = isAppt
                  ? t(`notif.appt.${apptSuffix}.title`)
                  : t(`notif.tipo.${n.type}.title`, { defaultValue: n.title, ...huecos });
                const apptBody = isAppt
                  ? t(`notif.appt.${apptSuffix}.body`, { name: ad.specialist_name || ad.recipient_name || '', title: ad.title || '', reason: ad.reason || '' })
                  : t(`notif.tipo.${n.type}.body`, { defaultValue: n.body, ...huecos });
                const forumTitle = isForumNew ? t('notif.forumNew.title') : isForumPending ? t('notif.forumPending.title') : isForumApproved ? t('notif.forumApproved.title') : isForumModCall ? t('notif.forumModCall.title') : t('notif.forumModApproved.title');
                const forumBody = isForumNew ? t('notif.forumNew.body', { title: fd.title || '' }) : isForumPending ? t('notif.forumPending.body') : isForumApproved ? t('notif.forumApproved.body', { title: fd.title || '' }) : isForumModCall ? t('notif.forumModCall.body', { title: fd.title || '' }) : t('notif.forumModApproved.body');
                const rowTitle = isGrace ? graceTitle : isInviteOpen ? t('notif.inviteOpened.title') : isForum ? forumTitle : isTopicJob ? t('notif.topicJob.title') : isTopicVenue ? t('notif.topicVenue.title') : isBooking ? t('notif.booking.title') : isDM ? t('notif.dm.title') : isWaitSlot ? t('notif.waitlist.title') : isWaitJoin ? t('notif.waitlist.join') : n.type === 'referral_reward' ? t('notif.referral.reward') : isReferral ? t('notif.referral.title') : isCommission ? t('notif.commission.title') : isDirMatch ? t('notif.dirMatch.title') : apptTitle;
                const rowBody = isGrace ? graceBody : isInviteOpen ? t('notif.inviteOpened.body', { name: invOpenName }) : isForum ? forumBody : isTopicJob ? t('notif.topicJob.body', { type: t(`labor.type.${td.opportunity_type}`, { defaultValue: '' }), place: tPlace }) : isTopicVenue ? t('notif.topicVenue.body', { name: td.name || '', place: tPlace }) : isBooking ? t('notif.booking.body', { name: (n.data as { name?: string } | null)?.name ?? '' }) : isDM ? t('notif.dm.body', { name: ad.from_name || '' }) : apptBody;
                return (
                  <li key={n.id}>
                    <button
                      type="button"
                      onClick={() => {
                        if (!n.is_read) void markRead(n.id);
                        // Antes ningún aviso navegaba: pulsarlo sólo lo marcaba
                        // leído. (Hallazgo M-7.)
                        const destino = notifDestino(n.type, n.data);
                        if (destino) { setOpen(false); navigate(destino); }
                      }}
                      className={`w-full rounded-xl p-2.5 text-left ${n.is_read ? 'bg-white' : 'bg-brand-50'}`}
                    >
                      <div className="flex items-center gap-2">
                        {isAchievement && <Trophy className="h-4 w-4 shrink-0 text-warm-500" />}
                        {isBadge && <Award className="h-4 w-4 shrink-0 text-brand-600" />}
                        {isAppt && <CalendarClock className="h-4 w-4 shrink-0 text-brand-600" />}
                        {isMsg && <Megaphone className="h-4 w-4 shrink-0 text-brand-600" />}
                        {isDM && <MessageSquare className="h-4 w-4 shrink-0 text-brand-600" />}
                        {isBooking && <CalendarClock className="h-4 w-4 shrink-0 text-brand-600" />}
                        {(isWaitSlot || isWaitJoin) && <Users className="h-4 w-4 shrink-0 text-brand-600" />}
                        {isCampaign && <Megaphone className="h-4 w-4 shrink-0 text-brand-600" />}
                        {isReferral && <Gift className="h-4 w-4 shrink-0 text-brand-600" />}
                        {isCommission && <HandCoins className="h-4 w-4 shrink-0 text-sage-600" />}
                        {isDirMatch && <Compass className="h-4 w-4 shrink-0 text-brand-600" />}
                        {isSuspReminder && <PauseCircle className="h-4 w-4 shrink-0 text-amber-600" />}
                        {isCosto && <AlertTriangle className="h-4 w-4 shrink-0 text-amber-600" />}
                        {isTopicJob && <Briefcase className="h-4 w-4 shrink-0 text-brand-600" />}
                        {isTopicVenue && <Ticket className="h-4 w-4 shrink-0 text-brand-600" />}
                        {isForum && <Users className="h-4 w-4 shrink-0 text-brand-600" />}
                        {isInviteOpen && <MailOpen className="h-4 w-4 shrink-0 text-amber-600" />}
                        {isGrace && <AlertTriangle className="h-4 w-4 shrink-0 text-amber-600" />}
                        <span className="text-sm font-semibold text-slate-900">{rowTitle}</span>
                      </div>
                      {rowBody && <p className="mt-0.5 text-sm text-slate-600">{rowBody}</p>}
                      {isAchievement && (
                        <p className="mt-1 text-xs text-muted">
                          {t('notif.viewersReport', { count })} · {t('notif.keepGoing')}
                        </p>
                      )}
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}
