/**
 * EsparcimientoRegister — registro de un lugar de "Esparcimiento" (provider_type
 * = 'tourism', reetiquetado). Cines, restaurantes, museos, parques, hoteles… con
 * ubicación geográfica y datos de accesibilidad: horarios de bajo impacto
 * sensorial y adaptaciones cognitivas/otras.
 *
 * Guarda lo específico en provider_details (venue_type, sensory_hours,
 * cognitive_adaptations, other_adaptations, city, address) y el tipo de lugar
 * también en specialties[] para que sea indexable en el buscador.
 */
import { useState } from 'react';
import { leerCoordenadas } from '@/lib/coordenadas';
import { entregarFotoDeRegistro } from '@/lib/fotoPendiente';
import { useAuthStore } from '@/stores/authStore';
import { useTranslation } from 'react-i18next';
import { setFounderOptoutFlag } from '@/lib/founderPref';
import { isStrongPassword } from '@/lib/password';
import { isStrictEmail } from '@/lib/email';
import { useCountryLabel } from '@/lib/countryLabel';
import { FounderProgressCard } from '@/components/founder/FounderProgressCard';
import { MembershipPrice } from '@/components/registration/MembershipPrice';
import { SectionsField } from '@/components/onboarding/SectionsField';
import { founderKindFor } from '@/hooks/useFounder';
import { Camera, Eye, ChevronDown, MapPin, Ticket } from 'lucide-react';
import { Button, useToast, PasswordInput } from '@/components/ui';
import { useAuth } from '@/hooks/useAuth';
import { useCatLabel } from '@/lib/catLabel';
import { RULES_VERSION } from '@/lib/legal';
import { COUNTRIES } from '@/data/countries';
import { VENUE_TYPES } from '@/data/esparcimientoCatalog';
import { useCountryField } from '@/hooks/useCountryField';

// Los campos llevan fondo propio y borde definido para que se distingan del
// papel blanco de la tarjeta; al enfocarlos pasan a blanco con anillo, de modo
// que siempre se vea cuál se está llenando.
const inputCls = 'w-full rounded-xl border border-slate-300 bg-slate-50 p-3 text-base transition-colors hover:border-slate-400 focus-visible:border-brand-400 focus-visible:bg-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-500';
// El PAÍS no es un campo más: de él dependen la cuota y la moneda del cobro.
// Va resaltado en azul para que se vea antes que el resto y no se conteste al
// descuido.
const countryCls = 'w-full rounded-xl border-2 border-brand-400 bg-brand-50 p-3 text-base font-semibold text-slate-900 transition-colors focus-visible:bg-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-500';
const countryHintCls = 'mt-1 text-xs font-medium text-brand-700';
const labelCls = 'mb-1 block font-semibold text-slate-900';
const sectionTitle = 'text-sm font-semibold uppercase tracking-wide text-muted';

export function EsparcimientoRegister({ onSuccess, complete = false }: { onSuccess?: () => void; complete?: boolean }) {
  const { t } = useTranslation();
  const countryLabel = useCountryLabel();
  const catLabel = useCatLabel();
  const { signUp, completeProfile } = useAuth();
  const toast = useToast();

  const [name, setName] = useState('');
  const [logoUrl, setLogoUrl] = useState<string | null>(null);
  // El archivo, no solo la vista previa: antes se tiraba al enviar.
  const [archivoFoto, setArchivoFoto] = useState<File | null>(null);
  const [venueType, setVenueType] = useState('');
  const [description, setDescription] = useState('');
  const [sections, setSections] = useState<string[]>([]);
  const [neuroConditions, setNeuroConditions] = useState<string[]>([]);
  const toggleSection = (v: string) => setSections((l) => (l.includes(v) ? l.filter((x) => x !== v) : [...l, v]));
  const toggleCondition = (v: string) => setNeuroConditions((l) => (l.includes(v) ? l.filter((x) => x !== v) : [...l, v]));
  // Ubicación geográfica
  // Enlazado al store: el país que ve en los precios es el que se guarda.
  const [country, setCountry] = useCountryField();
  const [city, setCity] = useState('');
  const [address, setAddress] = useState('');
  const [mapUrl, setMapUrl] = useState('');
  const [lat, setLat] = useState('');
  const [lng, setLng] = useState('');

  /**
   * El enlace de Google Maps YA se pedía, y las coordenadas venían dentro. Se
   * leen de ahí en vez de pedirle a la persona que las busque aparte.
   * (M-17, ampliación pedida el 16 oct 2026.)
   */
  const cambiarMapUrl = (valor: string) => {
    setMapUrl(valor);
    const c = leerCoordenadas(valor);
    if (c) { setLat(String(c.lat)); setLng(String(c.lng)); }
  };

  /**
   * Google Maps entrega UNA cadena («19.4326, -99.1332»); el formulario pedía
   * DOS números. Quien pegaba la cadena completa aquí dejaba la longitud vacía
   * y se guardaba sin pin, sin decir nada. Ahora se reparte sola.
   */
  const pegarCoordenadas = (valor: string) => {
    const c = leerCoordenadas(valor);
    if (c) { setLat(String(c.lat)); setLng(String(c.lng)); return; }
    setLat(valor);
  };
  // Accesibilidad
  const [sensoryHours, setSensoryHours] = useState('');
  const [cognitive, setCognitive] = useState('');
  const [otherAdapt, setOtherAdapt] = useState('');
  // Contacto
  const [phone, setPhone] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [website, setWebsite] = useState('');
  const [instagram, setInstagram] = useState('');
  const [facebook, setFacebook] = useState('');
  // Cuenta
  const [email, setEmail] = useState('');
  const [confirmEmail, setConfirmEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [acceptTerms, setAcceptTerms] = useState(false);
  const [acceptRules, setAcceptRules] = useState(false);
  const [acceptManifesto, setAcceptManifesto] = useState(false);
  const [wantsFounder, setWantsFounder] = useState(true);
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [missing, setMissing] = useState<string[]>([]);

  const onLogo = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) { setLogoUrl(URL.createObjectURL(f)); setArchivoFoto(f); }
  };

  const submit = async () => {
    const miss: string[] = [];
    if (name.trim().length < 2) miss.push(t('esp.miss.name'));
    if (contactEmail.trim() && !isStrictEmail(contactEmail)) miss.push(t('reg.miss.emailValid'));
    if (!country) miss.push(t('reg.miss.country'));
    if (!complete) {
      if (!email.trim()) miss.push(t('reg.miss.email'));
      if (email.trim() && !isStrictEmail(email)) miss.push(t('reg.miss.emailValid'));
      if (email.trim().toLowerCase() !== confirmEmail.trim().toLowerCase()) miss.push(t('reg.miss.emailMatch'));
      if (password.length < 8) miss.push(t('reg.miss.password'));
      else if (!isStrongPassword(password)) miss.push(t('reg.miss.passwordWeak'));
      if (password !== confirmPassword) miss.push(t('reg.miss.passwordMatch'));
    }
    if (!acceptTerms) miss.push(t('reg.miss.terms'));
    if (!acceptRules) miss.push(t('reg.miss.rules'));
    if (!acceptManifesto) miss.push(t('reg.miss.manifesto'));
    if (miss.length) { setMissing(miss); return; }
    setMissing([]);
    setFounderOptoutFlag(!wantsFounder);
    setBusy(true);

    const details: Record<string, unknown> = {};
    if (venueType) details.venue_type = venueType;
    if (city.trim()) details.city = city.trim();
    if (address.trim()) details.address_text = address.trim();
    if (mapUrl.trim()) details.map_url = mapUrl.trim();
    if (sensoryHours.trim()) details.sensory_hours = sensoryHours.trim();
    if (cognitive.trim()) details.cognitive_adaptations = cognitive.trim();
    if (otherAdapt.trim()) details.other_adaptations = otherAdapt.trim();
    if (contactEmail.trim()) details.contact_email = contactEmail.trim();

    // Ubicación geográfica: si hay coordenadas válidas, se crea una sucursal con
    // lat/long para que el lugar aparezca con pin en el mapa del directorio.
    const latN = parseFloat(lat), lngN = parseFloat(lng);
    const hasCoords = !Number.isNaN(latN) && !Number.isNaN(lngN) && Math.abs(latN) <= 90 && Math.abs(lngN) <= 180;
    const locations = hasCoords
      ? [{ label: name.trim() || null, address: address.trim() || city.trim() || name.trim(), country: country || null, latitude: latN, longitude: lngN }]
      : undefined;

    const payload = {
      email, password, fullName: name.trim(),
      role: 'provider' as const, providerType: 'tourism' as const, isCompany: true, businessName: name.trim(),
      bio: description || null, website: website || null, phone: phone || null,
      instagram: instagram || null, facebook: facebook || null,
      country: country || null, address: address || null,
      specialties: venueType ? [venueType] : [], // indexable para el buscador
      sections, neuroConditions,
      providerDetails: details,
      ...(locations ? { locations } : {}),
      rulesVersion: RULES_VERSION,
    };
    const res = complete ? await completeProfile(payload) : await signUp(payload);
    setBusy(false);
    if (!res.ok) { toast.error(res.error); return; }

    // LA FOTO. Antes solo se mostraba una vista previa y el archivo se tiraba,
    // mientras la pantalla decia que se subiria en el primer acceso. Ahora es
    // verdad: si ya hay sesion sube aqui, y si no, queda guardada en este
    // dispositivo y useFotoPendiente la sube al entrar.
    if (archivoFoto) {
      const uid = useAuthStore.getState().user?.id ?? null;
      const comoFue = await entregarFotoDeRegistro(archivoFoto, uid);
      if (comoFue === 'subida') toast.success(t('reg.fotoSubida'));
      else if (comoFue === 'pendiente') toast.success(t('reg.fotoPendiente'));
      else toast.error(t('reg.fotoFallo'));
    }
    if (logoUrl) toast.success(t('k.logoLater'));
    try { localStorage.setItem('neuromundi.pendingWelcome', '1'); } catch { /* ignore */ }
    if (complete) { onSuccess?.(); return; }
    setDone(true);
  };

  if (done) {
    return (
      <div className="rounded-xl bg-brand-50 p-4 text-center text-sm text-slate-700">
        {t('auth.checkEmail')}
        <p className="mt-2 text-muted">{t('esp.afterInfo')}</p>
        <p className="mt-2 text-sm font-medium text-brand-700">{t('reg.afterConfirmPay')}</p>
      </div>
    );
  }

  const founderKind = founderKindFor('provider', 'tourism');
  const preview = (
    <>
      <div className="rounded-2xl border border-slate-100 bg-white p-5 shadow-sm">
        <p className="mb-3 text-xs font-semibold uppercase tracking-wide text-muted">{t('k.previewTitle')}</p>
        <div className="flex items-center gap-3">
          <div className="flex h-16 w-16 shrink-0 items-center justify-center overflow-hidden rounded-xl bg-gradient-to-br from-sky-500 to-cyan-600 text-white">
            {logoUrl ? <img src={logoUrl} alt="" className="h-full w-full object-cover" /> : <Ticket className="h-7 w-7" />}
          </div>
          <div className="min-w-0">
            <p className="truncate font-bold text-slate-900">{name || t('esp.yourName')}</p>
            <p className="text-sm text-brand-700">{t('create.cards.tourism.title')}</p>
            {(city || country) && (
              <p className="flex items-center gap-1 text-xs text-muted"><MapPin className="h-3 w-3" /> {[city, country].filter(Boolean).join(', ')}</p>
            )}
          </div>
        </div>
        {venueType && <p className="mt-3 inline-block rounded-full bg-brand-50 px-2 py-0.5 text-xs text-brand-700">{catLabel(venueType, VENUE_TYPES.find((v) => v.value === venueType)?.label ?? venueType)}</p>}
        {sensoryHours && <p className="mt-3 line-clamp-2 text-xs text-slate-600"><span className="font-semibold">{t('esp.sensoryHours')}:</span> {sensoryHours}</p>}
      </div>
      <MembershipPrice boxed hideIfEmpty className="mt-4" affiliate="tourism" />
      {founderKind ? <FounderProgressCard kind={founderKind} country={country || null} /> : null}
    </>
  );

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
      <form onSubmit={(e) => { e.preventDefault(); void submit(); }} className="space-y-6" noValidate>
        {/* País de residencia, primero: de él dependen los precios que se
            muestran arriba, así que la persona confirma su costo ANTES de
            llenar el resto del formulario. */}
        <section className="space-y-4">
              <div>
                <label className={labelCls} htmlFor="esparc-f3">{t('reg.country')}</label>
                <select id="esparc-f3" className={countryCls} value={country} onChange={(e) => setCountry(e.target.value)}>
                  <option value="">{t('reg.selectCountry')}</option>
                  {COUNTRIES.map((c) => <option key={c.code} value={c.name}>{countryLabel(c.code, c.name)}</option>)}
                </select>
                <p className={countryHintCls}>{t('reg.countryFeeHint')}</p>
              </div>

              {/* En móvil la barra lateral es `hidden lg:block`, así que el precio
                  no se renderizaba nunca. Aquí se muestra junto al país. */}
              <MembershipPrice boxed hideIfEmpty affiliate="tourism" className="lg:hidden" />
        </section>

        {/* 1. El lugar */}
        <section className="space-y-4">
          <h3 className={sectionTitle}>{t('esp.s1')}</h3>
          <div className="flex items-center gap-4">
            <label className="flex h-20 w-20 shrink-0 cursor-pointer items-center justify-center overflow-hidden rounded-xl bg-gradient-to-br from-sky-500 to-cyan-600 text-white/80 ring-2 ring-slate-100">
              {logoUrl ? <img src={logoUrl} alt="" className="h-full w-full object-cover" /> : <Camera className="h-6 w-6" />}
              <input type="file" accept="image/*" className="hidden" onChange={onLogo} />
            </label>
            <p className="text-xs text-muted">{t('k.logoHint')}</p>
          </div>
          <div><label className={labelCls} htmlFor="esparc-f0">{t('esp.name')} *</label><input id="esparc-f0" className={inputCls} value={name} onChange={(e) => setName(e.target.value)} /></div>
          <div>
            <label className={labelCls} htmlFor="esparc-f1">{t('esp.venueType')}</label>
            <select id="esparc-f1" className={inputCls} value={venueType} onChange={(e) => setVenueType(e.target.value)}>
              <option value="">{t('esp.selectVenue')}</option>
              {VENUE_TYPES.map((v) => <option key={v.value} value={v.value}>{catLabel(v.value, v.label)}</option>)}
            </select>
          </div>
          <div>
            <label className={labelCls} htmlFor="esparc-f2">{t('esp.description')}</label>
            <textarea id="esparc-f2" maxLength={400} rows={3} className={inputCls} value={description} onChange={(e) => setDescription(e.target.value)} />
            <p className="mt-1 text-right text-xs text-muted">{description.length}/400</p>
          </div>
        </section>

        {/* 2. Ubicación geográfica */}
        <section className="space-y-4">
          <h3 className={sectionTitle}>{t('esp.s2')}</h3>
          <SectionsField
            sections={sections}
            onToggleSection={toggleSection}
            neuroConditions={neuroConditions}
            onToggleCondition={toggleCondition}
          />
          <div className="grid gap-3 sm:grid-cols-2">
            <div><label className={labelCls} htmlFor="esparc-f4">{t('esp.city')}</label><input id="esparc-f4" className={inputCls} value={city} onChange={(e) => setCity(e.target.value)} /></div>
          </div>
          <div><label className={labelCls} htmlFor="esparc-f5">{t('esp.address')}</label><input id="esparc-f5" className={inputCls} value={address} onChange={(e) => setAddress(e.target.value)} /></div>
          <div><label className={labelCls} htmlFor="esparc-f6">{t('esp.mapUrl')}</label><input id="esparc-f6" className={inputCls} value={mapUrl} onChange={(e) => cambiarMapUrl(e.target.value)} placeholder="https://maps.google.com/…" /><p className="mt-1 text-xs text-muted">{t('esp.mapUrlHelp')}</p></div>
          <div className="grid gap-3 sm:grid-cols-2">
            <div><label className={labelCls} htmlFor="esparc-f7">{t('esp.lat')}</label><input id="esparc-f7" className={inputCls} inputMode="decimal" value={lat} onChange={(e) => pegarCoordenadas(e.target.value)} placeholder="19.4326" /></div>
            <div><label className={labelCls} htmlFor="esparc-f8">{t('esp.lng')}</label><input id="esparc-f8" className={inputCls} inputMode="decimal" value={lng} onChange={(e) => setLng(e.target.value)} placeholder="-99.1332" /></div>
          </div>
          <p className="text-xs text-muted">{t('esp.coordsHelp')}</p>
          {leerCoordenadas(`${lat},${lng}`) && <p className="text-xs font-semibold text-sage-700">{t('esp.coordsOk')}</p>}
        </section>

        {/* 3. Accesibilidad sensorial y cognitiva */}
        <section className="space-y-4">
          <h3 className={sectionTitle}>{t('esp.s3')}</h3>
          <div><label className={labelCls} htmlFor="esparc-f9">{t('esp.sensoryHours')}</label><textarea id="esparc-f9" rows={2} className={inputCls} value={sensoryHours} onChange={(e) => setSensoryHours(e.target.value)} placeholder={t('esp.sensoryHoursPlaceholder')} /></div>
          <div><label className={labelCls} htmlFor="esparc-f10">{t('esp.cognitive')}</label><textarea id="esparc-f10" rows={2} className={inputCls} value={cognitive} onChange={(e) => setCognitive(e.target.value)} placeholder={t('esp.cognitivePlaceholder')} /></div>
          <div><label className={labelCls} htmlFor="esparc-f11">{t('esp.otherAdapt')}</label><textarea id="esparc-f11" rows={2} className={inputCls} value={otherAdapt} onChange={(e) => setOtherAdapt(e.target.value)} /></div>
        </section>

        {/* 4. Contacto */}
        <section className="space-y-4">
          <h3 className={sectionTitle}>{t('esp.s4')}</h3>
          <div className="grid gap-3 sm:grid-cols-2">
            <div><label className={labelCls} htmlFor="esparc-f12">{t('k.whatsapp')}</label><input id="esparc-f12" className={inputCls} value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+52 55…" /></div>
            <div><label className={labelCls} htmlFor="esparc-f13">{t('k.contactEmail')}</label><input id="esparc-f13" type="email" className={inputCls} value={contactEmail} onChange={(e) => setContactEmail(e.target.value)} /></div>
            <div><label className={labelCls} htmlFor="esparc-f14">{t('k.website')}</label><input id="esparc-f14" className={inputCls} value={website} onChange={(e) => setWebsite(e.target.value)} placeholder="https://" /></div>
            <div><label className={labelCls} htmlFor="esparc-f15">{t('reg.instagram')}</label><input id="esparc-f15" className={inputCls} value={instagram} onChange={(e) => setInstagram(e.target.value)} placeholder="@usuario" /></div>
            <div><label className={labelCls} htmlFor="esparc-f16">{t('reg.facebook')}</label><input id="esparc-f16" className={inputCls} value={facebook} onChange={(e) => setFacebook(e.target.value)} placeholder="https://facebook.com/…" /></div>
          </div>
        </section>

        {/* 5. Cuenta */}
        {!complete && (
          <section className="space-y-4">
            <h3 className={sectionTitle}>{t('k.s6')}</h3>
            <div><label className={labelCls} htmlFor="esparc-f17">{t('auth.email')}</label><input id="esparc-f17" type="email" className={inputCls} value={email} onChange={(e) => setEmail(e.target.value)} /></div>
            <div><label className={labelCls} htmlFor="esparc-f18">{t('auth.confirmEmail')}</label><input id="esparc-f18" type="email" inputMode="email" autoComplete="off" onPaste={(e) => e.preventDefault()} className={inputCls} value={confirmEmail} onChange={(e) => setConfirmEmail(e.target.value)} /></div>
            <div><label className={labelCls}>{t('auth.password')}</label><PasswordInput className={inputCls} value={password} onChange={(e) => setPassword(e.target.value)} /></div>
            <div><label className={labelCls}>{t('auth.confirmPassword')}</label><PasswordInput className={inputCls} value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} /></div>
          </section>
        )}

        <label className="flex items-start gap-3 text-sm text-slate-700">
          <input type="checkbox" className="mt-0.5 h-5 w-5 rounded border-slate-300 text-brand-500" checked={acceptTerms} onChange={(e) => setAcceptTerms(e.target.checked)} />
          <span>{t('reg.acceptPre')}{' '}<a href="/terms" target="_blank" rel="noopener noreferrer" className="font-semibold text-brand-700 underline">{t('auth.terms')}</a>{' '}{t('reg.acceptMid')}{' '}<a href="/privacy" target="_blank" rel="noopener noreferrer" className="font-semibold text-brand-700 underline">{t('auth.privacy')}</a>{t('reg.acceptPost')}</span>
        </label>
        <label className="flex items-start gap-3 text-sm text-slate-700">
          <input type="checkbox" className="mt-0.5 h-5 w-5 rounded border-slate-300 text-brand-500" checked={acceptRules} onChange={(e) => setAcceptRules(e.target.checked)} />
          <span>{t('reg.acceptRulesPre')}{' '}<a href="/reglamento" target="_blank" rel="noopener noreferrer" className="font-semibold text-brand-700 underline">{t('reg.rulesLink')}</a>{t('reg.acceptRulesPost')}</span>
        </label>
        <label className="flex items-start gap-3 text-sm text-slate-700">
          <input type="checkbox" className="mt-0.5 h-5 w-5 rounded border-slate-300 text-brand-500" checked={acceptManifesto} onChange={(e) => setAcceptManifesto(e.target.checked)} />
          <span>{t('reg.acceptManifestoPre')} <a href="/manifiesto" target="_blank" rel="noopener noreferrer" className="font-semibold text-brand-700 underline">{t('footer.manifesto')}</a>{t('reg.acceptManifestoPost')}</span>
        </label>
        <label className="flex items-start gap-3 rounded-xl border border-brand-100 bg-brand-50 p-3 text-sm text-slate-700">
          <input type="checkbox" className="mt-0.5 h-5 w-5 rounded border-slate-300 text-brand-500" checked={wantsFounder} onChange={(e) => setWantsFounder(e.target.checked)} />
          <span><span className="font-semibold text-slate-900">{t('reg.wantFounder')}</span> {t('reg.wantFounderHint')}{!wantsFounder ? ` — ${t('reg.ordinaryDiscount')}` : ''}</span>
        </label>

        {missing.length > 0 && (
          <div role="alert" className="rounded-lg bg-red-50 p-3 text-sm text-evs-1">
            <p className="font-semibold">{t('reg.missTitle')}</p>
            <ul className="mt-1 list-disc pl-5">
              {missing.map((m, i) => <li key={i}>{m}</li>)}
            </ul>
          </div>
        )}
        <Button type="submit" loading={busy} fullWidth>{complete ? t('onb.finish') : t('auth.createAccount')}</Button>
      </form>

      <aside className="hidden lg:block">
        <div className="sticky top-20">{preview}</div>
      </aside>
      <div className="lg:hidden">
        <button type="button" onClick={() => setShowPreview((s) => !s)} className="flex w-full items-center justify-between rounded-xl border border-slate-200 p-3 text-sm font-semibold text-slate-700">
          <span className="flex items-center gap-2"><Eye className="h-4 w-4" /> {t('k.previewToggle')}</span>
          <ChevronDown className={`h-4 w-4 transition ${showPreview ? 'rotate-180' : ''}`} />
        </button>
        {showPreview && <div className="mt-3">{preview}</div>}
      </div>
    </div>
  );
}
