/**
 * Messages — mensajería directa (/mensajes, protegida).
 *
 * Lista de conversaciones + hilo + redactor. El especialista puede iniciar una
 * conversación por folio (NM-000123) y enviar enlaces de video-sesión de
 * cualquier plataforma (Zoom, Meet, Teams…) o crear una sala Jitsi al vuelo.
 * Los enlaces en los mensajes se muestran como enlaces clicables.
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import { useEmpresaLimitada } from '@/hooks/useEmpresaLimitada';
import { EmpresaLimitadaMuro } from '@/components/membership/EmpresaLimitadaMuro';
import { useTranslation } from 'react-i18next';
import { MessageSquare, Send, Video, ArrowLeft, Plus, Search, FileText, Trash2 } from 'lucide-react';
import { Button, useToast, EmptyState, Avatar, SkeletonCard } from '@/components/ui';
import { useMessages, type Message, type Thread } from '@/hooks/useMessages';
import { useMessageTemplates } from '@/hooks/useMessageTemplates';
import { useAuth } from '@/hooks/useAuth';
import { jitsiRoomUrl } from '@/lib/meet';
import { formatDate } from '@/lib/utils';
import { supabase } from '@/lib/supabase';

interface MemberHit {
  member_no: number;
  full_name: string;
  business_name: string | null;
  avatar_url: string | null;
  role: string;
}

const folio6 = (n: number) => `NM-${String(n).padStart(6, '0')}`;

const URL_RE = /(https?:\/\/[^\s]+)/g;

function Linkified({ text }: { text: string }) {
  const parts = text.split(URL_RE);
  return (
    <>
      {parts.map((p, i) =>
        /^https?:\/\//.test(p) ? (
          <a key={i} href={p} target="_blank" rel="noopener noreferrer" className="break-all underline">
            {p}
          </a>
        ) : (
          <span key={i}>{p}</span>
        ),
      )}
    </>
  );
}

function folioToNumber(raw: string): number | null {
  const digits = raw.replace(/\D/g, '');
  if (!digits) return null;
  const n = Number(digits);
  return Number.isFinite(n) && n > 0 ? n : null;
}

export function Messages() {
  const { limitada: empresaLimitada } = useEmpresaLimitada();
  const { t } = useTranslation();
  const toast = useToast();
  const { isAdmin, isProvider } = useAuth();
  const { userId, threads, loading, reloadThreads, fetchThread, markThreadRead, send } = useMessages();

  // Plantillas de respuesta rápida: para quien escribe mucho (prestador/admin).
  const canTemplate = isProvider || isAdmin;
  const { templates, create: createTpl, remove: removeTpl } = useMessageTemplates(canTemplate);
  const [tplOpen, setTplOpen] = useState(false);

  const createTemplate = async (body: string) => {
    if (!body.trim()) return;
    // El título es la primera línea recortada; suficiente para reconocerla.
    const ok = await createTpl(body.split('\n')[0].slice(0, 40), body);
    toast[ok ? 'success' : 'error'](ok ? t('tpl.saved') : t('tpl.error'));
  };
  const removeTemplate = async (id: string) => {
    const ok = await removeTpl(id);
    if (!ok) toast.error(t('tpl.error'));
  };

  const [active, setActive] = useState<Thread | null>(null);
  const [msgs, setMsgs] = useState<Message[]>([]);
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const [newOpen, setNewOpen] = useState(false);
  const [folio, setFolio] = useState('');
  // Búsqueda de miembro (solo admin): por folio, nombre o apellido.
  const [query, setQuery] = useState('');
  const [hits, setHits] = useState<MemberHit[]>([]);
  const [searching, setSearching] = useState(false);
  const [picked, setPicked] = useState<MemberHit | null>(null);
  const endRef = useRef<HTMLDivElement>(null);

  // Busca miembros mientras el admin escribe (con un pequeño retraso para no
  // disparar una consulta por cada tecla).
  useEffect(() => {
    if (!newOpen) return;
    const q = query.trim();
    if (q.length < 2) { setHits([]); return; }
    let alive = true;
    setSearching(true);
    const id = window.setTimeout(async () => {
      const { data } = await supabase.rpc('search_contacts', { p_query: q });
      if (alive) { setHits((data as MemberHit[] | null) ?? []); setSearching(false); }
    }, 300);
    return () => { alive = false; window.clearTimeout(id); };
  }, [query, newOpen]);

  const openThread = useCallback(async (th: Thread) => {
    setActive(th);
    setNewOpen(false);
    const list = await fetchThread(th.other_id);
    setMsgs(list);
    if (th.unread > 0) { await markThreadRead(th.other_id); void reloadThreads(); }
  }, [fetchThread, markThreadRead, reloadThreads]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [msgs]);

  const doSend = async (memberNo: number) => {
    const body = text.trim();
    if (!body) return;
    setBusy(true);
    const r = await send(memberNo, body);
    setBusy(false);
    if (!r.ok) {
      toast.error(t(`msg.err.${r.error}`, t('msg.err.generic')));
      return;
    }
    setText('');
    await reloadThreads();
    if (active) {
      setMsgs(await fetchThread(active.other_id));
    } else {
      // Conversación nueva: localizar el hilo recién creado y abrirlo.
      const { data } = await supabase.rpc('message_threads');
      const th = ((data as Thread[]) ?? []).find((x) => x.other_member_no === memberNo) ?? null;
      setNewOpen(false);
      setFolio('');
      if (th) { setActive(th); setMsgs(await fetchThread(th.other_id)); }
    }
  };

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (active?.other_member_no != null) { void doSend(active.other_member_no); return; }
    // Admin que eligió a alguien de la búsqueda: se usa ese folio.
    if (picked) { void doSend(picked.member_no); return; }
    const n = folioToNumber(folio);
    if (n == null) { toast.error(t('msg.badFolio')); return; }
    void doSend(n);
  };

  const openNew = () => {
    setNewOpen(true);
    setActive(null);
    setMsgs([]);
    setFolio('');
    setQuery('');
    setHits([]);
    setPicked(null);
  };

  const pickMember = (m: MemberHit) => {
    setPicked(m);
    setFolio(String(m.member_no));
    setHits([]);
    setQuery('');
  };

  const insertRoom = () => {
    const url = jitsiRoomUrl(active?.other_id || undefined);
    setText((v) => (v ? `${v}\n${url}` : `${t('msg.roomPrefix')} ${url}`));
  };

  // Empresa con 45 días sin publicar oferta: esta pantalla queda limitada
  // hasta que publique una (migración 0223). No hay cargo de por medio.
  if (empresaLimitada) return <EmpresaLimitadaMuro />;

  return (
    <main className="mx-auto max-w-5xl p-4">
      <h1 className="mb-4 flex items-center gap-2 text-2xl font-bold text-slate-900">
        <MessageSquare className="h-6 w-6 text-brand-600" /> {t('msg.title')}
      </h1>

      <div className="grid gap-4 md:grid-cols-[320px_1fr]">
        {/* Lista de conversaciones */}
        <aside className={active || newOpen ? 'hidden md:block' : 'block'}>
          <Button fullWidth variant="secondary" onClick={openNew} leadingIcon={<Plus className="h-4 w-4" />}>
            {t('msg.new')}
          </Button>
          <div className="mt-3 space-y-1">
            {loading ? (
              <SkeletonCard rows={3} />
            ) : threads.length === 0 ? (
              <p className="px-2 py-6 text-center text-sm text-muted">{t('msg.emptyThreads')}</p>
            ) : (
              threads.map((th) => (
                <button
                  key={th.other_id}
                  type="button"
                  onClick={() => void openThread(th)}
                  className={`flex w-full items-center gap-3 rounded-xl p-2.5 text-left hover:bg-slate-50 ${active?.other_id === th.other_id ? 'bg-brand-50' : ''}`}
                >
                  <Avatar name={th.other_name ?? '—'} src={th.other_avatar} size="sm" />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <span className="truncate text-sm font-semibold text-slate-900">{th.other_name ?? t('msg.someone')}</span>
                      {th.unread > 0 && (
                        <span className="flex h-4 min-w-4 items-center justify-center rounded-full bg-evs-1 px-1 text-[10px] font-bold text-white">{th.unread}</span>
                      )}
                    </div>
                    <p className="truncate text-xs text-muted">{th.last_body}</p>
                  </div>
                </button>
              ))
            )}
          </div>
        </aside>

        {/* Hilo / redactor */}
        <section className={!active && !newOpen ? 'hidden md:block' : 'block'}>
          {!active && !newOpen ? (
            <EmptyState icon={<MessageSquare className="h-6 w-6" />} title={t('msg.pickTitle')} description={t('msg.pickDesc')} />
          ) : (
            <div className="flex h-[70vh] flex-col rounded-2xl border border-slate-100 bg-white shadow-sm">
              <header className="flex items-center gap-2 border-b border-slate-100 p-3">
                <button type="button" className="md:hidden" onClick={() => { setActive(null); setNewOpen(false); }} aria-label={t('common.back')}>
                  <ArrowLeft className="h-5 w-5 text-slate-600" />
                </button>
                {active ? (
                  <>
                    <Avatar name={active.other_name ?? '—'} src={active.other_avatar} size="sm" />
                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold text-slate-900">{active.other_name ?? t('msg.someone')}</p>
                      {active.other_member_no != null && (
                        <p className="font-mono text-xs text-muted">NM-{String(active.other_member_no).padStart(6, '0')}</p>
                      )}
                    </div>
                  </>
                ) : (
                  <div className="relative flex-1">
                    {/* Búsqueda entre TUS contactos (con quienes ya tienes
                        relación previa): por folio, nombre o apellido. */}
                    {(
                      <div className="mb-2">
                        <label className="text-xs font-semibold text-slate-700">{t('msg.searchLabel')}</label>
                        <div className="relative mt-1">
                          <Search className="pointer-events-none absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" aria-hidden="true" />
                          <input
                            value={query}
                            onChange={(e) => { setQuery(e.target.value); setPicked(null); }}
                            placeholder={t('msg.searchPlaceholder')}
                            className="w-full rounded-lg border border-slate-200 py-1.5 pl-8 pr-3 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-500"
                          />
                        </div>
                        {/* Resultados */}
                        {(hits.length > 0 || searching) && (
                          <ul className="absolute z-10 mt-1 max-h-64 w-full overflow-auto rounded-xl border border-slate-200 bg-white shadow-lg">
                            {searching && hits.length === 0 ? (
                              <li className="px-3 py-2 text-sm text-muted">{t('msg.searching')}</li>
                            ) : (
                              hits.map((m) => (
                                <li key={m.member_no}>
                                  <button
                                    type="button"
                                    onClick={() => pickMember(m)}
                                    className="flex w-full items-center gap-2 px-3 py-2 text-left hover:bg-slate-50"
                                  >
                                    <Avatar name={m.business_name || m.full_name || '—'} src={m.avatar_url} size="sm" />
                                    <span className="min-w-0 flex-1">
                                      <span className="block truncate text-sm font-medium text-slate-900">
                                        {m.business_name || m.full_name || t('msg.someone')}
                                      </span>
                                      <span className="block font-mono text-xs text-muted">{folio6(m.member_no)}</span>
                                    </span>
                                  </button>
                                </li>
                              ))
                            )}
                          </ul>
                        )}
                      </div>
                    )}
                    {/* Alternativa: escribir el folio exacto directamente. */}
                    {(
                      <>
                        <label className="text-xs font-semibold text-slate-700">{t('msg.toFolio')}</label>
                        <input
                          value={folio}
                          onChange={(e) => { setFolio(e.target.value); setPicked(null); }}
                          placeholder="NM-000123"
                          className="mt-1 w-48 rounded-lg border border-slate-200 px-3 py-1.5 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-500"
                        />
                      </>
                    )}
                    {picked && (
                      <p className="text-xs text-brand-700">
                        {t('msg.toName', { name: picked.business_name || picked.full_name })}
                      </p>
                    )}
                  </div>
                )}
              </header>

              <div className="flex-1 space-y-2 overflow-y-auto p-3">
                {active && msgs.length === 0 ? (
                  <p className="py-8 text-center text-sm text-muted">{t('msg.threadEmpty')}</p>
                ) : (
                  msgs.map((m) => {
                    const mine = m.sender_id === userId;
                    return (
                      <div key={m.id} className={`flex ${mine ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-[80%] whitespace-pre-wrap break-words rounded-2xl px-3 py-2 text-sm ${mine ? 'bg-brand-700 text-white' : 'bg-slate-100 text-slate-900'}`}>
                          <Linkified text={m.body} />
                          <div className={`mt-1 text-[10px] ${mine ? 'text-white/70' : 'text-muted'}`}>{formatDate(m.created_at)}</div>
                        </div>
                      </div>
                    );
                  })
                )}
                <div ref={endRef} />
              </div>

              <form onSubmit={onSubmit} className="border-t border-slate-100 p-3">
                {/* Plantillas de respuesta rápida (solo prestador/admin). */}
                {canTemplate && tplOpen && (
                  <div className="mb-2 rounded-xl border border-slate-200 bg-white p-2 shadow-sm">
                    <div className="mb-1 flex items-center justify-between">
                      <span className="text-xs font-semibold text-slate-700">{t('tpl.title')}</span>
                      <button
                        type="button"
                        onClick={() => { void createTemplate(text); }}
                        disabled={!text.trim()}
                        className="text-xs font-semibold text-brand-700 hover:underline disabled:text-muted"
                      >
                        {t('tpl.saveCurrent')}
                      </button>
                    </div>
                    {templates.length === 0 ? (
                      <p className="px-1 py-2 text-xs text-muted">{t('tpl.empty')}</p>
                    ) : (
                      <ul className="max-h-48 space-y-1 overflow-auto">
                        {templates.map((tp) => (
                          <li key={tp.id} className="flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => { setText((v) => (v ? `${v}\n${tp.body}` : tp.body)); setTplOpen(false); }}
                              className="min-w-0 flex-1 truncate rounded-lg px-2 py-1.5 text-left text-sm hover:bg-slate-50"
                              title={tp.body}
                            >
                              <span className="font-medium text-slate-900">{tp.title}</span>
                            </button>
                            <button type="button" onClick={() => void removeTemplate(tp.id)} aria-label={t('common.delete')} className="text-evs-1 hover:opacity-80">
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                )}
                <div className="flex items-end gap-2">
                  <button type="button" onClick={insertRoom} title={t('msg.room')} className="rounded-full p-2 text-brand-600 hover:bg-brand-50">
                    <Video className="h-5 w-5" />
                  </button>
                  {canTemplate && (
                    <button
                      type="button"
                      onClick={() => setTplOpen((v) => !v)}
                      title={t('tpl.title')}
                      aria-pressed={tplOpen}
                      className={`rounded-full p-2 ${tplOpen ? 'bg-brand-50 text-brand-700' : 'text-brand-600 hover:bg-brand-50'}`}
                    >
                      <FileText className="h-5 w-5" />
                    </button>
                  )}
                  <textarea
                    value={text}
                    onChange={(e) => setText(e.target.value)}
                    rows={2}
                    placeholder={t('msg.placeholder')}
                    className="flex-1 resize-none rounded-xl border border-slate-200 px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-500"
                  />
                  <Button type="submit" loading={busy} disabled={!text.trim()} leadingIcon={<Send className="h-4 w-4" />}>
                    {t('msg.send')}
                  </Button>
                </div>
                <p className="mt-1 text-[11px] text-muted">{t('msg.hint')}</p>
              </form>
            </div>
          )}
        </section>
      </div>
    </main>
  );
}
