/**
 * Home — portada pública. El héroe invita a elegir el PAÍS: al seleccionarlo,
 * el directorio y demás secciones quedan segmentados a ese país sin que la
 * persona tenga que volver a filtrar. La selección se guarda en el dispositivo.
 */
import { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Compass, ShieldCheck, Heart, Lock, BookOpenCheck, ArrowRight, UserPlus, MessageCircleQuestion, Sprout, Sparkles, Stethoscope } from 'lucide-react';
import { SECTIONS } from '@/data/sections';

/** Iconos por sección (SECTIONS.icon es un nombre; aquí se mapea). */
const SECTION_ICONS = { Sprout, Sparkles, Stethoscope } as const;
import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui';
import { SearchableSelect } from '@/components/directory/SearchableSelect';
import { FoundersCounter } from '@/components/campaign/FoundersCounter';
import { ComingSoonBanner } from '@/components/campaign/ComingSoonBanner';
import { lazy, Suspense } from 'react';

import { HomeCounters } from '@/components/home/HomeCounters';
import { AcademicAllyBand } from '@/components/home/AcademicAllyBand';
import { HeartHandshake, Award } from 'lucide-react';
import { useCountry } from '@/stores/countryStore';
import { COUNTRIES } from '@/data/countries';
import { useInView } from '@/hooks/useInView';

// Banner de distintivos (10 imágenes): fuera del bundle inicial y montado al
// acercarse al viewport, para no cargar su DOM/imágenes en la ruta crítica.
const MemberBadgesBanner = lazy(() => import('@/components/home/MemberBadgesBanner').then((m) => ({ default: m.MemberBadgesBanner })));

// Bajo el pliegue y con consulta propia a Supabase: fuera del bundle inicial y
// de la hidratación crítica; se montan al acercarse al viewport (useInView).
const ComparisonTable = lazy(() => import('@/components/home/ComparisonTable').then((m) => ({ default: m.ComparisonTable })));
const WelcomeVideoHome = lazy(() => import('@/components/home/WelcomeVideoHome').then((m) => ({ default: m.WelcomeVideoHome })));
// Asoma el blog y los eventos. Consulta propia a Supabase, así que va fuera del
// bundle inicial y se monta al acercarse al viewport, igual que los de arriba.
const HomeBlogEvents = lazy(() => import('@/components/home/HomeBlogEvents').then((m) => ({ default: m.HomeBlogEvents })));

export function Home() {
  const navigate = useNavigate();
  const { t, i18n } = useTranslation();
  const { country, setCountry } = useCountry();
  const [badgesRef, badgesInView] = useInView<HTMLDivElement>();
  const [videoRef, videoInView] = useInView<HTMLDivElement>();
  const [cmpRef, cmpInView] = useInView<HTMLDivElement>();
  const [peekRef, peekInView] = useInView<HTMLDivElement>();

  // Nombre del país localizado para mostrar; el `value` sigue siendo el nombre
  // canónico (español) para que coincida con `profiles.country` al filtrar.
  const countries = useMemo(() => {
    let display: (code: string) => string = (c) => c;
    try {
      const dn = new Intl.DisplayNames([i18n.language], { type: 'region' });
      display = (code) => dn.of(code) ?? code;
    } catch {
      /* Intl.DisplayNames no disponible: usamos el nombre en español */
    }
    return COUNTRIES
      .map((c) => ({ value: c.name, label: display(c.code) || c.name }))
      .sort((a, b) => a.label.localeCompare(b.label, i18n.language));
  }, [i18n.language]);

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <div className="mb-6"><ComingSoonBanner /></div>
      {/* HÉROE */}
      <section className="grid items-start gap-8 lg:grid-cols-2">
        <div className="order-last text-left lg:order-first">
          <h1 className="text-3xl font-extrabold leading-tight text-slate-900 sm:text-4xl">
            {t('home.title')}
          </h1>
          <ul className="mt-4 flex flex-col items-start gap-2">
            {SECTIONS.map((s) => {
              const Icon = SECTION_ICONS[s.icon];
              return (
                <li key={s.value}>
                  <span className={`inline-flex items-center gap-2 rounded-full px-4 py-2 text-base font-bold ${s.chip}`}>
                    <Icon className="h-5 w-5 shrink-0" aria-hidden="true" />
                    {t(`sections.${s.value}.name`)}
                  </span>
                </li>
              );
            })}
          </ul>

          {/* Selector de país */}
          <div className="mt-6 rounded-2xl border border-slate-100 bg-white p-4 shadow-md">
            <p className="mb-1 block text-sm font-semibold text-slate-900">
              {t('home.country.label')}
            </p>
            <div className="flex flex-col gap-2 sm:flex-row">
              {/* Selector con búsqueda: no pinta las ~250 opciones hasta que se abre,
                  quitando ese coste de "Style & Layout" del primer render. */}
              <SearchableSelect
                className="flex-1"
                options={countries}
                value={country ?? ''}
                onChange={(v) => setCountry(v || null)}
                placeholder={t('home.country.all')}
                searchPlaceholder={t('home.country.search')}
                noMatches={t('home.country.noMatch')}
                ariaLabel={t('home.country.label')}
              />
              <Button type="button" size="lg" onClick={() => navigate('/directorio')} leadingIcon={<Compass className="h-5 w-5" />}>
                {t('home.country.cta')}
              </Button>
            </div>
            <p className="mt-2 text-sm text-muted">
              {country ? t('home.country.selected', { country }) : t('home.country.hint')}
            </p>
          </div>

          <p className="mt-3 text-sm text-muted">{t('home.search.free')}</p>

          {/* Accesos rápidos a la comunidad, al experto y a los kits.
             Tarjetas blancas elevadas: despegan del fondo pálido del héroe y se
             leen como acciones pulsables, un escalón por debajo del buscador. */}
          {/* Accesos rápidos como BOTONES con color por acción + flecha: destacan
              como pulsables y se distinguen entre sí sin competir con el botón
              primario azul "Explorar directorio". */}
          <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-3">
            {[
              { icon: <UserPlus className="h-5 w-5" />, label: t('home.cta.join'), to: '/crear-cuenta',
                border: 'border-brand-600', iconBg: 'bg-brand-600', text: 'text-brand-800', ring: 'focus-visible:ring-brand-500' },
              { icon: <MessageCircleQuestion className="h-5 w-5" />, label: t('home.cta.expert'), to: '/pregunta-al-experto',
                border: 'border-teal-600', iconBg: 'bg-teal-600', text: 'text-teal-800', ring: 'focus-visible:ring-teal-500' },
              { icon: <BookOpenCheck className="h-5 w-5" />, label: t('home.cta.kits'), to: '/kit',
                border: 'border-amber-600', iconBg: 'bg-amber-600', text: 'text-amber-800', ring: 'focus-visible:ring-amber-500' },
            ].map((c) => (
              <button
                key={c.to}
                onClick={() => navigate(c.to)}
                className={`group flex items-center gap-3 rounded-2xl border-2 ${c.border} bg-white px-4 py-3.5 text-start shadow-sm min-h-[44px] transition-all motion-safe:duration-150 hover:shadow-md motion-safe:hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 ${c.ring}`}
              >
                <span className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${c.iconBg} text-white`}>
                  {c.icon}
                </span>
                <span className={`flex-1 font-semibold leading-snug ${c.text}`}>{c.label}</span>
              </button>
            ))}
          </div>

          {/* ¿Cómo ser fundador?: centrado bajo los accesos rápidos de la columna. */}
          <div className="mt-5 flex justify-center">
            <button
              type="button"
              onClick={() => navigate('/become-a-founder')}
              className="inline-flex items-center gap-2 rounded-full border-2 border-brand-500 bg-white px-5 py-2.5 text-sm font-bold text-brand-700 shadow-sm transition-colors hover:bg-brand-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-500 focus-visible:ring-offset-2"
            >
              <Award className="h-4 w-4" aria-hidden="true" /> {t('home.becomeFounderBtn')}
            </button>
          </div>
        </div>

        <div className="order-first lg:order-last">
          {/* Contadores "Neuromundi en cifras": ocupan el lugar del antiguo
              carrusel, en la mitad superior (máxima visibilidad). */}
          <HomeCounters />
        </div>
      </section>

      <FoundersCounter />

      {/* Confianza */}
      <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        <Feature icon={<Heart className="h-6 w-6" />} title={t('home.f1.title')}>{t('home.f1.body')}</Feature>
        <Feature icon={<ShieldCheck className="h-6 w-6" />} title={t('home.f2.title')}>{t('home.f2.body')}</Feature>
        <Feature icon={<Compass className="h-6 w-6" />} title={t('home.f3.title')}>{t('home.f3.body')}</Feature>
        <Feature icon={<Lock className="h-6 w-6" />} title={t('home.f4.title')}>{t('home.f4.body')}</Feature>
      </div>

      {/* Blog y eventos: dos fichas contiguas con ejemplos reales, para que el
          visitante se percate de que las dos secciones existen. Van ARRIBA de
          «¿Qué es Neuromundi?», donde todavía está decidiendo si le sirve. */}
      <div ref={peekRef}>
        {peekInView && (
          <Suspense fallback={<div className="mt-16 h-64 rounded-2xl bg-slate-50" />}>
            <HomeBlogEvents />
          </Suspense>
        )}
      </div>

      {/* Acerca + Video + invitación al Kit — tres columnas en escritorio, apiladas en móvil */}
      <section className="mt-16 grid items-stretch gap-8 lg:grid-cols-3">
        <div className="flex flex-col justify-center">
          <h2 className="text-2xl font-bold text-slate-900">{t('home.about.title')}</h2>
          <p className="mt-3 text-muted">{t('home.about.body1')}</p>
          <p className="mt-3 text-muted">{t('home.about.body2')}</p>
          <div className="mt-5">
            <Button variant="secondary" aria-label={t('info.title')} onClick={() => navigate('/conocer-mas')} trailingIcon={<ArrowRight className="h-4 w-4" />}>
              {t('home.about.more')}
            </Button>
          </div>
        </div>

        {/* Columna central: video de bienvenida (vista previa + modal). Diferido
            del bundle inicial; se monta al acercarse al viewport. La caja reserva
            altura para no provocar salto de diseño (CLS) mientras carga. */}
        <div ref={videoRef} className="flex min-h-[360px] flex-col">
          {videoInView && <Suspense fallback={null}><WelcomeVideoHome /></Suspense>}
        </div>

        <div className="overflow-hidden rounded-3xl border border-brand-100 bg-gradient-to-br from-brand-50 to-white p-6 sm:p-8">
          <div className="flex h-full flex-col justify-center">
            <span className="inline-flex w-fit items-center gap-2 rounded-full bg-white px-3 py-1 text-sm font-semibold text-brand-700 shadow-sm">
              <BookOpenCheck className="h-4 w-4" aria-hidden="true" /> {t('kit.badge')}
            </span>
            <h2 className="mt-3 text-2xl font-bold text-slate-900">{t('kit.home.title')}</h2>
            <p className="mt-2 leading-relaxed text-slate-700">{t('kit.home.text')}</p>
            <Button className="mt-5 w-fit" size="lg" onClick={() => navigate('/kit')} leadingIcon={<BookOpenCheck className="h-5 w-5" />}>
              {t('kit.home.cta')}
            </Button>
          </div>
        </div>
      </section>

      {/* Comparativa: Neuromundi frente a los directorios/plataformas más usados.
          Diferida (consulta Supabase + DOM pesado): fuera del bundle inicial, se
          monta al acercarse al viewport. */}
      <div ref={cmpRef}>
        {cmpInView && <Suspense fallback={null}><ComparisonTable /></Suspense>}
      </div>

      {/* Fundadores + Donantes: dos tarjetas gemelas (mismo contenedor degradado
          que la sección del Kit). Cada una conduce a su muro. En móvil se apilan. */}
      <section className="mt-16 grid items-stretch gap-8 lg:grid-cols-2">
        <div className="overflow-hidden rounded-3xl border border-brand-100 bg-gradient-to-br from-brand-50 to-white p-6 sm:p-8">
          <div className="flex h-full flex-col justify-center">
            <span className="inline-flex w-fit items-center gap-2 rounded-full bg-white px-3 py-1 text-sm font-semibold text-brand-700 shadow-sm">
              <Award className="h-4 w-4" aria-hidden="true" /> {t('home.founders.badge')}
            </span>
            <h2 className="mt-3 text-2xl font-bold text-slate-900">{t('home.founders.title')}</h2>
            <p className="mt-2 leading-relaxed text-slate-700">{t('home.founders.body')}</p>
            <div className="mt-5 flex flex-wrap gap-2">
              <Button size="lg" onClick={() => navigate('/fundadores')} leadingIcon={<Award className="h-5 w-5" />}>
                {t('home.founders.cta')}
              </Button>
            </div>
          </div>
        </div>

        <div className="overflow-hidden rounded-3xl border border-brand-100 bg-gradient-to-br from-brand-50 to-white p-6 sm:p-8">
          <div className="flex h-full flex-col justify-center">
            <span className="inline-flex w-fit items-center gap-2 rounded-full bg-white px-3 py-1 text-sm font-semibold text-brand-700 shadow-sm">
              <HeartHandshake className="h-4 w-4" aria-hidden="true" /> {t('home.alliesPromo.badge')}
            </span>
            <h2 className="mt-3 text-2xl font-bold text-slate-900">{t('home.alliesPromo.title')}</h2>
            <p className="mt-2 leading-relaxed text-slate-700">{t('home.alliesPromo.body')}</p>
            <div className="mt-5 flex flex-wrap gap-2">
              <Button size="lg" onClick={() => navigate('/aliados')} leadingIcon={<HeartHandshake className="h-5 w-5" />}>
                {t('home.alliesPromo.cta')}
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Aliado académico: Observatorio Internacional de Neuroeducación y Neurodiversidad. */}
      <AcademicAllyBand />

      {/* Distintivos para miembros Neuromundi: al fondo de la portada.
          Diferido por viewport para aligerar la carga (DOM e imágenes). */}
      <div ref={badgesRef} className="mt-16">
        {badgesInView && <Suspense fallback={null}><MemberBadgesBanner /></Suspense>}
      </div>

    </div>
  );
}

function Feature({ icon, title, children }: { icon: React.ReactNode; title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-slate-100 bg-white p-5 text-left shadow-sm">
      <span className="flex h-11 w-11 items-center justify-center rounded-full bg-brand-50 text-brand-700">{icon}</span>
      <h2 className="mt-3 font-bold text-slate-900">{title}</h2>
      <p className="mt-1 text-sm text-muted">{children}</p>
    </div>
  );
}
